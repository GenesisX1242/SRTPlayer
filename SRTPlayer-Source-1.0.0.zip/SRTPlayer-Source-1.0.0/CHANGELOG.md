# Changelog

## 1.0.0

- Consolidated public release containing the complete feature set developed through the previous internal builds.
- Added immediate layered-window rendering and an in-window startup progress indicator.
- Global keyboard-hook initialization runs after the first visible frame on a dedicated Windows thread.
- Added single-instance forwarding, visible-window correction, asynchronous SRT parsing, and a native Windows file dialog.
- Preserved dynamic shortcuts, continuous seek, speed rules, progress controls, drag-and-drop, resizable subtitle and settings windows, appearance settings, default/reset controls, installer, and uninstaller.
