# SRT Player 1.0.0（Windows 11）

SRT Player 是离线 SRT 外挂字幕显示器，只维护字幕时间轴，不控制外部视频，也不联网。

## 主要功能

- 拖放或快捷键加载 `.srt`。
- 全局快捷键、长按连续快进、动态快捷键规则。
- 快进、相对速度和指定速度规则。
- 可拖动进度条及后退、播放/暂停、快进按钮。
- 无边框置顶字幕窗口，可缩放，滚轮调整字号。
- 背景颜色和透明度可调。
- 设置为默认、重置设置。
- 单实例运行、窗口位置自动校正、后台解析 SRT。
- 启动时立即绘制窗口，并在后台初始化全局快捷键。

## 默认快捷键

- `Space`：播放/暂停。
- `Shift+Right`：前进 1 s。
- `Shift+Left`：后退 1 s。
- `Right`：前进 5 s。
- `Left`：后退 5 s。
- `Ctrl+Right`：速度增加 0.1 倍。
- `Ctrl+Left`：速度减少 0.1 倍。
- `S`：速度设为 1.0 倍。
- `Ctrl+Alt+O`：打开字幕。
- `Ctrl+Alt+F12`：全局快捷键总开关。

## 配置文件

配置文件保存在 `SRTPlayer.exe` 所在目录：

```text
settings.json
default_settings.json
factory_settings.json
```

## 安装和卸载

安装器支持自定义安装目录、安装进度条和桌面快捷方式。安装目录内包含 `uninstall.exe`，同时会登记到 Windows“已安装的应用”。

默认安装目录：

```text
%LOCALAPPDATA%\Programs\SRT Player
```

## 从源码构建

需要 Windows 11、PowerShell 和 Go 1.21 或更高版本：

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

输出：

```text
dist\SRTPlayer.exe
dist\SRTPlayer-1.0.0.exe
dist\uninstall.exe
dist\SRTPlayer-Setup-1.0.0.exe
```

当前只支持 UTF-8 或 UTF-8 BOM 编码的 `.srt`。安装包未数字签名，Windows 可能显示未知发布者提示。
