module srtplayer

go 1.21
