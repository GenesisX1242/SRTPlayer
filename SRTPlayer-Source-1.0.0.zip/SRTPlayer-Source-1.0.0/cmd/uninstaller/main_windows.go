//go:build windows

package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

var (
	user32          = syscall.NewLazyDLL("user32.dll")
	procMessageBoxW = user32.NewProc("MessageBoxW")
)

const (
	productMarker    = "SRTPlayer:b8193f3a-25fb-4f38-b42a-39f76237db66"
	oldProductMarker = "PenguinSubtitleOverlay:6f1ad3a2-7d8f-4b45-b03d-e8c75f6db5f1"

	MB_OK              = 0x00000000
	MB_YESNO           = 0x00000004
	MB_ICONINFORMATION = 0x00000040
	MB_ICONQUESTION    = 0x00000020
	IDYES              = 6
	CREATE_NO_WINDOW   = 0x08000000
)

func ptr(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func message(text, title string, flags uintptr) int {
	r, _, _ := procMessageBoxW.Call(0, uintptr(unsafe.Pointer(ptr(text))), uintptr(unsafe.Pointer(ptr(title))), flags)
	return int(r)
}
func hidden(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	return cmd.Run()
}
func removeRegistry() {
	_ = hidden("reg.exe", "delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\SRTPlayer`, "/f")
	_ = hidden("reg.exe", "delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, "/v", "SRTPlayer", "/f")
	_ = hidden("reg.exe", "delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\PenguinSubtitleOverlay`, "/f")
	_ = hidden("reg.exe", "delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, "/v", "PenguinSubtitleOverlay", "/f")
}
func quoteCmd(path string) string { return `"` + strings.ReplaceAll(path, `"`, `""`) + `"` }
func safeRemoveMarkedDir(dir, marker string) {
	data, err := os.ReadFile(filepath.Join(dir, "install.marker"))
	if err == nil && strings.TrimSpace(string(data)) == marker {
		_ = os.RemoveAll(dir)
	}
}

func main() {
	silent := len(os.Args) > 1 && strings.EqualFold(os.Args[1], "/S")
	if !silent {
		if message("将彻底移除 SRT Player、全局快捷键配置、窗口设置、快捷方式和卸载信息。\n\n也会清理旧版 Penguin Subtitle Overlay 的残留，但不会删除你自己的 SRT 字幕文件。是否继续？", "卸载 SRT Player", MB_YESNO|MB_ICONQUESTION) != IDYES {
			return
		}
	}

	exePath, _ := os.Executable()
	installDir := filepath.Dir(exePath)
	markerData, markerErr := os.ReadFile(filepath.Join(installDir, "install.marker"))
	if markerErr != nil || strings.TrimSpace(string(markerData)) != productMarker {
		if !silent {
			message("安全校验失败：当前目录不是由 SRT Player 安装器创建的程序目录。未删除任何文件。", "拒绝卸载", MB_OK|MB_ICONQUESTION)
		}
		return
	}

	local := os.Getenv("LOCALAPPDATA")
	appData := os.Getenv("APPDATA")
	userProfile := os.Getenv("USERPROFILE")

	_ = hidden("taskkill.exe", "/IM", "SRTPlayer.exe", "/F")
	_ = hidden("taskkill.exe", "/IM", "PenguinSubtitleOverlay.exe", "/F")
	removeRegistry()

	if local != "" {
		_ = os.RemoveAll(filepath.Join(local, "SRTPlayer"))
		_ = os.RemoveAll(filepath.Join(local, "PenguinSubtitleOverlay"))
		safeRemoveMarkedDir(filepath.Join(local, "Programs", "Penguin Subtitle Overlay"), oldProductMarker)
	}
	if appData != "" {
		_ = os.RemoveAll(filepath.Join(appData, "Microsoft", "Windows", "Start Menu", "Programs", "SRT Player"))
		_ = os.RemoveAll(filepath.Join(appData, "Microsoft", "Windows", "Start Menu", "Programs", "Penguin Subtitle Overlay"))
	}
	if userProfile != "" {
		_ = os.Remove(filepath.Join(userProfile, "Desktop", "SRT Player.lnk"))
		_ = os.Remove(filepath.Join(userProfile, "Desktop", "Penguin Subtitle Overlay.lnk"))
	}

	scriptPath := filepath.Join(os.TempDir(), fmt.Sprintf("SRTPlayer-remove-%d.cmd", os.Getpid()))
	script := "@echo off\r\n" +
		"ping 127.0.0.1 -n 3 >nul\r\n" +
		"rmdir /s /q " + quoteCmd(installDir) + "\r\n" +
		"del /f /q \"%~f0\"\r\n"
	_ = os.WriteFile(scriptPath, []byte(script), 0o600)

	if !silent {
		message("卸载操作已完成。程序目录将在本窗口关闭后自动删除。", "卸载完成", MB_OK|MB_ICONINFORMATION)
	}
	cmd := exec.Command("cmd.exe", "/C", scriptPath)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	_ = cmd.Start()
}
