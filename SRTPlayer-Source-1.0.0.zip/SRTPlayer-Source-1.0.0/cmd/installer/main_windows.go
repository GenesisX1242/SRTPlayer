//go:build windows

package main

import (
	"embed"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"unsafe"
)

//go:embed payload/SRTPlayer.exe payload/uninstall.exe payload/README.md payload/LICENSE.txt payload/SOURCE.txt payload/settings.json payload/default_settings.json payload/factory_settings.json
var payload embed.FS

const (
	appName    = "SRT Player"
	appVersion = "1.0.0"

	productMarker    = "SRTPlayer:b8193f3a-25fb-4f38-b42a-39f76237db66"
	oldProductMarker = "PenguinSubtitleOverlay:6f1ad3a2-7d8f-4b45-b03d-e8c75f6db5f1"

	WM_CREATE  = 0x0001
	WM_DESTROY = 0x0002
	WM_CLOSE   = 0x0010
	WM_COMMAND = 0x0111
	WM_SETFONT = 0x0030
	WM_APP     = 0x8000

	WM_APP_PROGRESS = WM_APP + 1
	WM_APP_DONE     = WM_APP + 2

	WS_OVERLAPPED   = 0x00000000
	WS_CAPTION      = 0x00C00000
	WS_SYSMENU      = 0x00080000
	WS_MINIMIZEBOX  = 0x00020000
	WS_VISIBLE      = 0x10000000
	WS_CHILD        = 0x40000000
	WS_TABSTOP      = 0x00010000
	WS_BORDER       = 0x00800000
	ES_AUTOHSCROLL  = 0x0080
	BS_AUTOCHECKBOX = 0x00000003

	WS_EX_CLIENTEDGE = 0x00000200

	SW_SHOW = 5

	COLOR_BTNFACE = 15
	IDC_ARROW     = 32512

	MB_OK              = 0x00000000
	MB_YESNO           = 0x00000004
	MB_ICONINFORMATION = 0x00000040
	MB_ICONERROR       = 0x00000010
	MB_ICONWARNING     = 0x00000030
	IDYES              = 6

	BN_CLICKED  = 0
	BST_CHECKED = 1

	PBM_SETRANGE32 = 0x0406
	PBM_SETPOS     = 0x0402

	BIF_RETURNONLYFSDIRS = 0x00000001
	BIF_NEWDIALOGSTYLE   = 0x00000040
	BIF_EDITBOX          = 0x00000010

	CREATE_NO_WINDOW = 0x08000000

	idPathEdit = 1001
	idBrowse   = 1002
	idDesktop  = 1003
	idInstall  = 1004
	idCancel   = 1005
	idLaunch   = 1006
)

type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}

type MSG struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      struct{ X, Y int32 }
}

type BROWSEINFO struct {
	HwndOwner      uintptr
	PidlRoot       uintptr
	PszDisplayName *uint16
	LpszTitle      *uint16
	UlFlags        uint32
	Lpfn           uintptr
	LParam         uintptr
	IImage         int32
}

type INITCOMMONCONTROLSEX struct {
	DwSize uint32
	DwICC  uint32
}

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	comctl32 = syscall.NewLazyDLL("comctl32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")

	procRegisterClassExW = user32.NewProc("RegisterClassExW")
	procCreateWindowExW  = user32.NewProc("CreateWindowExW")
	procDefWindowProcW   = user32.NewProc("DefWindowProcW")
	procShowWindow       = user32.NewProc("ShowWindow")
	procUpdateWindow     = user32.NewProc("UpdateWindow")
	procGetMessageW      = user32.NewProc("GetMessageW")
	procTranslateMessage = user32.NewProc("TranslateMessage")
	procDispatchMessageW = user32.NewProc("DispatchMessageW")
	procPostQuitMessage  = user32.NewProc("PostQuitMessage")
	procPostMessageW     = user32.NewProc("PostMessageW")
	procSendMessageW     = user32.NewProc("SendMessageW")
	procSetWindowTextW   = user32.NewProc("SetWindowTextW")
	procGetWindowTextW   = user32.NewProc("GetWindowTextW")
	procGetWindowTextLen = user32.NewProc("GetWindowTextLengthW")
	procEnableWindow     = user32.NewProc("EnableWindow")
	procDestroyWindow    = user32.NewProc("DestroyWindow")
	procMessageBoxW      = user32.NewProc("MessageBoxW")
	procLoadCursorW      = user32.NewProc("LoadCursorW")
	procLoadIconW        = user32.NewProc("LoadIconW")
	procGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")
	procCreateFontW      = gdi32.NewProc("CreateFontW")
	procInitCommon       = comctl32.NewProc("InitCommonControlsEx")
	procSHBrowse         = shell32.NewProc("SHBrowseForFolderW")
	procSHGetPath        = shell32.NewProc("SHGetPathFromIDListW")
	procCoTaskMemFree    = ole32.NewProc("CoTaskMemFree")
	procCoInitializeEx   = ole32.NewProc("CoInitializeEx")
	procCoUninitialize   = ole32.NewProc("CoUninitialize")

	mainWnd, pathEdit, browseBtn, desktopCheck, installBtn, cancelBtn uintptr
	progressBar, statusLabel, launchCheck                             uintptr
	uiFont                                                            uintptr
	installing, installFinished                                       bool
	installSucceeded                                                  bool
	statusMu                                                          sync.Mutex
	statusText                                                        string
	installErr                                                        error
)

func ptr(s string) *uint16      { p, _ := syscall.UTF16PtrFromString(s); return p }
func loword(v uintptr) uint16   { return uint16(v & 0xffff) }
func highword(v uintptr) uint16 { return uint16((v >> 16) & 0xffff) }

func message(owner uintptr, text, title string, flags uintptr) int {
	r, _, _ := procMessageBoxW.Call(owner, uintptr(unsafe.Pointer(ptr(text))), uintptr(unsafe.Pointer(ptr(title))), flags)
	return int(r)
}

func setText(hwnd uintptr, text string) {
	procSetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(ptr(text))))
}
func enable(hwnd uintptr, on bool) {
	v := uintptr(0)
	if on {
		v = 1
	}
	procEnableWindow.Call(hwnd, v)
}
func getText(hwnd uintptr) string {
	n, _, _ := procGetWindowTextLen.Call(hwnd)
	buf := make([]uint16, n+1)
	procGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}
func createControl(class, text string, exStyle, style uint32, x, y, w, height int32, parent uintptr, id int) uintptr {
	ctrl, _, _ := procCreateWindowExW.Call(uintptr(exStyle), uintptr(unsafe.Pointer(ptr(class))), uintptr(unsafe.Pointer(ptr(text))), uintptr(style), uintptr(x), uintptr(y), uintptr(w), uintptr(height), parent, uintptr(id), 0, 0)
	if ctrl != 0 && uiFont != 0 {
		procSendMessageW.Call(ctrl, WM_SETFONT, uiFont, 1)
	}
	return ctrl
}
func hidden(name string, args ...string) error {
	cmd := exec.Command(name, args...)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: CREATE_NO_WINDOW}
	return cmd.Run()
}
func psQuote(s string) string { return strings.ReplaceAll(s, "'", "''") }
func createShortcut(shortcut, target, workDir string) error {
	script := fmt.Sprintf(`$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut('%s'); $s.TargetPath='%s'; $s.WorkingDirectory='%s'; $s.Description='离线 SRT 外挂字幕播放器'; $s.Save()`, psQuote(shortcut), psQuote(target), psQuote(workDir))
	return hidden("powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script)
}
func regAdd(key, name, typ, value string) error {
	return hidden("reg.exe", "add", key, "/v", name, "/t", typ, "/d", value, "/f")
}
func safeRemoveMarkedDir(dir, marker string) {
	data, err := os.ReadFile(filepath.Join(dir, "install.marker"))
	if err == nil && strings.TrimSpace(string(data)) == marker {
		_ = os.RemoveAll(dir)
	}
}
func samePath(a, b string) bool {
	aa, _ := filepath.Abs(a)
	bb, _ := filepath.Abs(b)
	return strings.EqualFold(filepath.Clean(aa), filepath.Clean(bb))
}
func isDirectorySafe(dir string) bool {
	entries, err := os.ReadDir(dir)
	if os.IsNotExist(err) {
		return true
	}
	if err != nil {
		return false
	}
	if len(entries) == 0 {
		return true
	}
	data, err := os.ReadFile(filepath.Join(dir, "install.marker"))
	return err == nil && strings.TrimSpace(string(data)) == productMarker
}
func testWritable(dir string) error {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	test := filepath.Join(dir, ".srtplayer-write-test")
	if err := os.WriteFile(test, []byte("ok"), 0o600); err != nil {
		return err
	}
	return os.Remove(test)
}
func browseFolder(owner uintptr, initial string) string {
	_ = initial // SHBrowseForFolder has limited initial-folder support; the edit box retains the current path.
	display := make([]uint16, 260)
	bi := BROWSEINFO{HwndOwner: owner, PszDisplayName: &display[0], LpszTitle: ptr("请选择 SRT Player 的安装文件夹"), UlFlags: BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE | BIF_EDITBOX}
	pidl, _, _ := procSHBrowse.Call(uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return ""
	}
	defer procCoTaskMemFree.Call(pidl)
	pathBuf := make([]uint16, 32768)
	ok, _, _ := procSHGetPath.Call(pidl, uintptr(unsafe.Pointer(&pathBuf[0])))
	if ok == 0 {
		return ""
	}
	return syscall.UTF16ToString(pathBuf)
}

func setStatus(percent int, text string) {
	statusMu.Lock()
	statusText = text
	statusMu.Unlock()
	procPostMessageW.Call(mainWnd, WM_APP_PROGRESS, uintptr(percent), 0)
}
func embedded(name string) ([]byte, error) { return payload.ReadFile("payload/" + name) }
func writeEmbedded(targetDir, sourceName, targetName string, mode os.FileMode) error {
	data, err := embedded(sourceName)
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(targetDir, targetName), data, mode)
}
func copyIfExists(src, dst string) bool {
	data, err := os.ReadFile(src)
	if err != nil {
		return false
	}
	return os.WriteFile(dst, data, 0o600) == nil
}

func performInstall(installDir string, desktop bool) {
	defer func() { procPostMessageW.Call(mainWnd, WM_APP_DONE, 0, 0) }()
	setStatus(3, "正在检查安装目录…")
	if !isDirectorySafe(installDir) {
		installErr = fmt.Errorf("安装目录包含其他文件。为防止卸载时误删，请选择空目录或现有的 SRT Player 安装目录")
		return
	}
	if err := testWritable(installDir); err != nil {
		installErr = fmt.Errorf("安装目录不可写：%w", err)
		return
	}

	_ = hidden("taskkill.exe", "/IM", "SRTPlayer.exe", "/F")
	_ = hidden("taskkill.exe", "/IM", "PenguinSubtitleOverlay.exe", "/F")
	setStatus(12, "正在准备程序文件…")

	if err := writeEmbedded(installDir, "SRTPlayer.exe", "SRTPlayer.exe", 0o755); err != nil {
		installErr = err
		return
	}
	setStatus(27, "正在安装主程序…")
	if err := writeEmbedded(installDir, "uninstall.exe", "uninstall.exe", 0o755); err != nil {
		installErr = err
		return
	}
	if err := writeEmbedded(installDir, "README.md", "README.md", 0o644); err != nil {
		installErr = err
		return
	}
	if err := writeEmbedded(installDir, "LICENSE.txt", "LICENSE.txt", 0o644); err != nil {
		installErr = err
		return
	}
	if err := writeEmbedded(installDir, "SOURCE.txt", "SOURCE.txt", 0o644); err != nil {
		installErr = err
		return
	}
	if err := writeEmbedded(installDir, "factory_settings.json", "factory_settings.json", 0o644); err != nil {
		installErr = err
		return
	}
	setStatus(45, "正在安装默认设置…")

	local := os.Getenv("LOCALAPPDATA")
	appData := os.Getenv("APPDATA")
	userProfile := os.Getenv("USERPROFILE")
	settingsTarget := filepath.Join(installDir, "settings.json")
	defaultsTarget := filepath.Join(installDir, "default_settings.json")
	if _, err := os.Stat(settingsTarget); os.IsNotExist(err) {
		migrated := false
		if local != "" {
			migrated = copyIfExists(filepath.Join(local, "SRTPlayer", "settings.json"), settingsTarget)
			if !migrated {
				migrated = copyIfExists(filepath.Join(local, "PenguinSubtitleOverlay", "settings.json"), settingsTarget)
			}
		}
		if !migrated {
			if err := writeEmbedded(installDir, "settings.json", "settings.json", 0o600); err != nil {
				installErr = err
				return
			}
		}
	}
	if _, err := os.Stat(defaultsTarget); os.IsNotExist(err) {
		migrated := false
		if local != "" {
			migrated = copyIfExists(filepath.Join(local, "SRTPlayer", "default_settings.json"), defaultsTarget)
		}
		if !migrated {
			if err := writeEmbedded(installDir, "default_settings.json", "default_settings.json", 0o600); err != nil {
				installErr = err
				return
			}
		}
	}
	if err := os.WriteFile(filepath.Join(installDir, "install.marker"), []byte(productMarker), 0o600); err != nil {
		installErr = err
		return
	}
	setStatus(62, "正在创建快捷方式…")

	playerPath := filepath.Join(installDir, "SRTPlayer.exe")
	uninstallPath := filepath.Join(installDir, "uninstall.exe")
	if appData != "" {
		startMenu := filepath.Join(appData, "Microsoft", "Windows", "Start Menu", "Programs", "SRT Player")
		_ = os.RemoveAll(startMenu)
		_ = os.MkdirAll(startMenu, 0o755)
		_ = createShortcut(filepath.Join(startMenu, "SRT Player.lnk"), playerPath, installDir)
		_ = createShortcut(filepath.Join(startMenu, "卸载 SRT Player.lnk"), uninstallPath, installDir)
	}
	if desktop && userProfile != "" {
		_ = createShortcut(filepath.Join(userProfile, "Desktop", "SRT Player.lnk"), playerPath, installDir)
	}
	if !desktop && userProfile != "" {
		_ = os.Remove(filepath.Join(userProfile, "Desktop", "SRT Player.lnk"))
	}
	setStatus(77, "正在写入卸载信息…")

	key := `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\SRTPlayer`
	_ = regAdd(key, "DisplayName", "REG_SZ", "SRT Player")
	_ = regAdd(key, "DisplayVersion", "REG_SZ", appVersion)
	_ = regAdd(key, "Publisher", "REG_SZ", "GenesisX1242")
	_ = regAdd(key, "InstallLocation", "REG_SZ", installDir)
	_ = regAdd(key, "DisplayIcon", "REG_SZ", playerPath)
	_ = regAdd(key, "UninstallString", "REG_SZ", `"`+uninstallPath+`"`)
	_ = regAdd(key, "QuietUninstallString", "REG_SZ", `"`+uninstallPath+`" /S`)
	_ = regAdd(key, "NoModify", "REG_DWORD", "1")
	_ = regAdd(key, "NoRepair", "REG_DWORD", "1")
	_ = regAdd(key, "EstimatedSize", "REG_DWORD", "8192")

	setStatus(90, "正在清理旧版本…")
	if local != "" {
		oldDefault := filepath.Join(local, "Programs", "SRT Player")
		if !samePath(oldDefault, installDir) {
			safeRemoveMarkedDir(oldDefault, productMarker)
		}
		safeRemoveMarkedDir(filepath.Join(local, "Programs", "Penguin Subtitle Overlay"), oldProductMarker)
		_ = os.RemoveAll(filepath.Join(local, "SRTPlayer"))
		_ = os.RemoveAll(filepath.Join(local, "PenguinSubtitleOverlay"))
	}
	_ = hidden("reg.exe", "delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\PenguinSubtitleOverlay`, "/f")
	_ = hidden("reg.exe", "delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, "/v", "PenguinSubtitleOverlay", "/f")
	setStatus(100, "安装完成。")
	installSucceeded = true
}

func beginInstall() {
	installDir := strings.TrimSpace(getText(pathEdit))
	if installDir == "" {
		message(mainWnd, "请选择安装目录。", "安装路径", MB_OK|MB_ICONWARNING)
		return
	}
	installDir = filepath.Clean(os.ExpandEnv(installDir))
	setText(pathEdit, installDir)
	desktop, _, _ := procSendMessageW.Call(desktopCheck, 0x00F0, 0, 0) // BM_GETCHECK

	installing = true
	enable(pathEdit, false)
	enable(browseBtn, false)
	enable(desktopCheck, false)
	enable(installBtn, false)
	setText(cancelBtn, "取消")
	procSendMessageW.Call(progressBar, PBM_SETPOS, 0, 0)
	setText(statusLabel, "正在开始安装…")
	go performInstall(installDir, desktop == BST_CHECKED)
}

func wndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		createControl("STATIC", "SRT Player 安装向导", 0, WS_CHILD|WS_VISIBLE, 28, 22, 560, 30, hwnd, 0)
		createControl("STATIC", "请选择安装位置。程序文件、当前设置、默认设置和卸载程序都会保存在该目录中。", 0, WS_CHILD|WS_VISIBLE, 28, 58, 570, 42, hwnd, 0)
		createControl("STATIC", "安装目录", 0, WS_CHILD|WS_VISIBLE, 28, 117, 100, 22, hwnd, 0)
		pathEdit = createControl("EDIT", defaultInstallPath(), WS_EX_CLIENTEDGE, WS_CHILD|WS_VISIBLE|WS_TABSTOP|ES_AUTOHSCROLL, 28, 142, 470, 28, hwnd, idPathEdit)
		browseBtn = createControl("BUTTON", "浏览…", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP, 510, 141, 88, 30, hwnd, idBrowse)
		desktopCheck = createControl("BUTTON", "创建桌面快捷方式", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_AUTOCHECKBOX, 28, 190, 240, 24, hwnd, idDesktop)
		procSendMessageW.Call(desktopCheck, 0x00F1, BST_CHECKED, 0) // BM_SETCHECK
		progressBar = createControl("msctls_progress32", "", 0, WS_CHILD|WS_VISIBLE, 28, 241, 570, 22, hwnd, 0)
		procSendMessageW.Call(progressBar, PBM_SETRANGE32, 0, 100)
		statusLabel = createControl("STATIC", "准备安装。", 0, WS_CHILD|WS_VISIBLE, 28, 271, 570, 24, hwnd, 0)
		launchCheck = createControl("BUTTON", "安装完成后运行 SRT Player", 0, WS_CHILD|WS_TABSTOP|BS_AUTOCHECKBOX, 28, 305, 270, 24, hwnd, idLaunch)
		procSendMessageW.Call(launchCheck, 0x00F1, BST_CHECKED, 0)
		installBtn = createControl("BUTTON", "安装", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP, 408, 344, 90, 32, hwnd, idInstall)
		cancelBtn = createControl("BUTTON", "取消", 0, WS_CHILD|WS_VISIBLE|WS_TABSTOP, 508, 344, 90, 32, hwnd, idCancel)
		return 0
	case WM_COMMAND:
		id := int(loword(wParam))
		notify := highword(wParam)
		if notify == BN_CLICKED {
			switch id {
			case idBrowse:
				if selected := browseFolder(hwnd, getText(pathEdit)); selected != "" {
					setText(pathEdit, selected)
				}
			case idInstall:
				if installFinished {
					if installSucceeded {
						checked, _, _ := procSendMessageW.Call(launchCheck, 0x00F0, 0, 0)
						if checked == BST_CHECKED {
							cmd := exec.Command(filepath.Join(getText(pathEdit), "SRTPlayer.exe"))
							cmd.Dir = getText(pathEdit)
							_ = cmd.Start()
						}
					}
					procDestroyWindow.Call(hwnd)
				} else {
					beginInstall()
				}
			case idCancel:
				if installing {
					message(hwnd, "安装正在进行，请等待完成。", "SRT Player", MB_OK|MB_ICONINFORMATION)
				} else {
					procDestroyWindow.Call(hwnd)
				}
			}
		}
		return 0
	case WM_APP_PROGRESS:
		procSendMessageW.Call(progressBar, PBM_SETPOS, wParam, 0)
		statusMu.Lock()
		t := statusText
		statusMu.Unlock()
		setText(statusLabel, t)
		return 0
	case WM_APP_DONE:
		installing = false
		installFinished = true
		enable(cancelBtn, false)
		enable(installBtn, true)
		setText(installBtn, "完成")
		if installSucceeded {
			procShowWindow.Call(launchCheck, SW_SHOW)
			setText(statusLabel, "安装完成。SRT Player 已加入 Windows 的应用程序列表。")
			procSendMessageW.Call(progressBar, PBM_SETPOS, 100, 0)
		} else {
			setText(statusLabel, "安装失败。")
			message(hwnd, installErr.Error(), "安装失败", MB_OK|MB_ICONERROR)
		}
		return 0
	case WM_CLOSE:
		if installing {
			message(hwnd, "安装正在进行，请等待完成。", "SRT Player", MB_OK|MB_ICONINFORMATION)
			return 0
		}
		procDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func defaultInstallPath() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base = os.Getenv("USERPROFILE")
	}
	return filepath.Join(base, "Programs", "SRT Player")
}

func main() {
	runtime.LockOSThread()
	procCoInitializeEx.Call(0, 0x2) // COINIT_APARTMENTTHREADED, required by the folder picker.
	defer procCoUninitialize.Call()
	icc := INITCOMMONCONTROLSEX{DwSize: uint32(unsafe.Sizeof(INITCOMMONCONTROLSEX{})), DwICC: 0x00000020}
	procInitCommon.Call(uintptr(unsafe.Pointer(&icc)))
	hInstance, _, _ := procGetModuleHandleW.Call(0)
	cursor, _, _ := procLoadCursorW.Call(0, IDC_ARROW)
	icon, _, _ := procLoadIconW.Call(hInstance, 1)
	uiFont, _, _ = procCreateFontW.Call(^uintptr(15), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(ptr("Segoe UI"))))
	className := ptr("SRTPlayerInstallerClass")
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), LpfnWndProc: syscall.NewCallback(wndProc), HInstance: hInstance, HIcon: icon, HCursor: cursor, HbrBackground: COLOR_BTNFACE + 1, LpszClassName: className, HIconSm: icon}
	if r, _, _ := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		message(0, "无法创建安装界面。", "安装失败", MB_OK|MB_ICONERROR)
		return
	}
	mainWnd, _, _ = procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(ptr("SRT Player 安装向导"))), WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_VISIBLE, 0x80000000, 0x80000000, 646, 430, 0, 0, hInstance, 0)
	if mainWnd == 0 {
		message(0, "无法创建安装窗口。", "安装失败", MB_OK|MB_ICONERROR)
		return
	}
	procShowWindow.Call(mainWnd, SW_SHOW)
	procUpdateWindow.Call(mainWnd)
	var msg MSG
	for {
		r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}
}
