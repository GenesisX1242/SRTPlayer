//go:build windows

package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unicode/utf16"
	"unsafe"

	"srtplayer/internal/srt"
)

const (
	appName    = "SRT Player"
	appVersion = "1.0.0"

	WM_CREATE         = 0x0001
	WM_DESTROY        = 0x0002
	WM_MOVE           = 0x0003
	WM_SIZE           = 0x0005
	WM_GETMINMAXINFO  = 0x0024
	WM_NCCALCSIZE     = 0x0083
	WM_NCHITTEST      = 0x0084
	WM_NCACTIVATE     = 0x0086
	WM_SETFOCUS       = 0x0007
	WM_PAINT          = 0x000F
	WM_CLOSE          = 0x0010
	WM_QUIT           = 0x0012
	WM_ERASEBKGND     = 0x0014
	WM_COPYDATA       = 0x004A
	WM_COMMAND        = 0x0111
	WM_TIMER          = 0x0113
	WM_VSCROLL        = 0x0115
	WM_CONTEXTMENU    = 0x007B
	WM_GETDLGCODE     = 0x0087
	WM_NCDESTROY      = 0x0082
	WM_KEYDOWN        = 0x0100
	WM_KEYUP          = 0x0101
	WM_CHAR           = 0x0102
	WM_SYSKEYDOWN     = 0x0104
	WM_SYSKEYUP       = 0x0105
	WM_SYSCHAR        = 0x0106
	WM_MOUSEMOVE      = 0x0200
	WM_MOUSEWHEEL     = 0x020A
	WM_LBUTTONDOWN    = 0x0201
	WM_LBUTTONUP      = 0x0202
	WM_CAPTURECHANGED = 0x0215
	WM_DROPFILES      = 0x0233
	WM_MOUSELEAVE     = 0x02A3
	WM_NCLBUTTONDOWN  = 0x00A1
	WM_SETFONT        = 0x0030
	WM_APP            = 0x8000

	WM_APP_ACTION      = WM_APP + 1
	WM_APP_OPEN_RESULT = WM_APP + 2
	WM_APP_RULE        = WM_APP + 3
	WM_APP_SRT_LOADED  = WM_APP + 4
	WM_APP_HOOK_STATUS = WM_APP + 5
	WM_APP_ACTIVATE    = WM_APP + 6
	WM_APP_START_HOOK  = WM_APP + 7

	WS_POPUP       = 0x80000000
	WS_OVERLAPPED  = 0x00000000
	WS_CAPTION     = 0x00C00000
	WS_SYSMENU     = 0x00080000
	WS_MINIMIZEBOX = 0x00020000
	WS_MAXIMIZEBOX = 0x00010000
	WS_THICKFRAME  = 0x00040000
	WS_VISIBLE     = 0x10000000
	WS_CHILD       = 0x40000000
	WS_TABSTOP     = 0x00010000
	WS_BORDER      = 0x00800000
	WS_VSCROLL     = 0x00200000

	ES_AUTOHSCROLL   = 0x0080
	CBS_DROPDOWNLIST = 0x0003
	ES_READONLY      = 0x0800

	WS_EX_TOPMOST    = 0x00000008
	WS_EX_TOOLWINDOW = 0x00000080
	WS_EX_LAYERED    = 0x00080000

	SW_SHOW    = 5
	SW_RESTORE = 9

	CS_HREDRAW = 0x0002
	CS_VREDRAW = 0x0001

	IDC_ARROW    = 32512
	COLOR_WINDOW = 5

	DT_CENTER     = 0x00000001
	DT_RIGHT      = 0x00000002
	DT_VCENTER    = 0x00000004
	DT_WORDBREAK  = 0x00000010
	DT_SINGLELINE = 0x00000020
	DT_NOPREFIX   = 0x00000800
	DT_CALCRECT   = 0x00000400

	TRANSPARENT = 1
	FW_NORMAL   = 400
	FW_SEMIBOLD = 600

	LWA_ALPHA      = 0x00000002
	ULW_ALPHA      = 0x00000002
	AC_SRC_OVER    = 0x00
	AC_SRC_ALPHA   = 0x01
	BI_RGB         = 0
	DIB_RGB_COLORS = 0

	MF_STRING       = 0x00000000
	MF_SEPARATOR    = 0x00000800
	TPM_RIGHTBUTTON = 0x0002
	TPM_RETURNCMD   = 0x0100

	WH_KEYBOARD_LL = 13
	HC_ACTION      = 0

	VK_BACK       = 0x08
	VK_TAB        = 0x09
	VK_RETURN     = 0x0D
	VK_SHIFT      = 0x10
	VK_CONTROL    = 0x11
	VK_MENU       = 0x12
	VK_PAUSE      = 0x13
	VK_CAPITAL    = 0x14
	VK_ESCAPE     = 0x1B
	VK_SPACE      = 0x20
	VK_PRIOR      = 0x21
	VK_NEXT       = 0x22
	VK_END        = 0x23
	VK_HOME       = 0x24
	VK_LEFT       = 0x25
	VK_UP         = 0x26
	VK_RIGHT      = 0x27
	VK_DOWN       = 0x28
	VK_SNAPSHOT   = 0x2C
	VK_INSERT     = 0x2D
	VK_DELETE     = 0x2E
	VK_LWIN       = 0x5B
	VK_RWIN       = 0x5C
	VK_APPS       = 0x5D
	VK_NUMPAD0    = 0x60
	VK_MULTIPLY   = 0x6A
	VK_ADD        = 0x6B
	VK_SUBTRACT   = 0x6D
	VK_DECIMAL    = 0x6E
	VK_DIVIDE     = 0x6F
	VK_NUMLOCK    = 0x90
	VK_SCROLL     = 0x91
	VK_OEM_1      = 0xBA
	VK_OEM_PLUS   = 0xBB
	VK_OEM_COMMA  = 0xBC
	VK_OEM_MINUS  = 0xBD
	VK_OEM_PERIOD = 0xBE
	VK_OEM_2      = 0xBF
	VK_OEM_3      = 0xC0
	VK_OEM_4      = 0xDB
	VK_OEM_5      = 0xDC
	VK_OEM_6      = 0xDD
	VK_OEM_7      = 0xDE

	HTCLIENT      = 1
	HTCAPTION     = 2
	HTLEFT        = 10
	HTRIGHT       = 11
	HTTOP         = 12
	HTTOPLEFT     = 13
	HTTOPRIGHT    = 14
	HTBOTTOM      = 15
	HTBOTTOMLEFT  = 16
	HTBOTTOMRIGHT = 17

	TME_LEAVE = 0x00000002

	MONITOR_DEFAULTTONEAREST = 0x00000002
	ERROR_ALREADY_EXISTS     = 183
	SMTO_ABORTIFHUNG         = 0x0002
	OFN_HIDEREADONLY         = 0x00000004
	OFN_NOCHANGEDIR          = 0x00000008
	OFN_PATHMUSTEXIST        = 0x00000800
	OFN_FILEMUSTEXIST        = 0x00001000
	OFN_EXPLORER             = 0x00080000

	DLGC_WANTARROWS  = 0x0001
	DLGC_WANTTAB     = 0x0002
	DLGC_WANTALLKEYS = 0x0004

	EM_SETSEL = 0x00B1

	CB_GETCURSEL  = 0x0147
	CB_ADDSTRING  = 0x0143
	CB_SETCURSEL  = 0x014E
	CBN_SELCHANGE = 1

	SB_LINEUP        = 0
	SB_LINEDOWN      = 1
	SB_PAGEUP        = 2
	SB_PAGEDOWN      = 3
	SB_THUMBPOSITION = 4
	SB_THUMBTRACK    = 5
	SB_TOP           = 6
	SB_BOTTOM        = 7
	SB_ENDSCROLL     = 8
	SB_VERT          = 1
	SIF_RANGE        = 0x0001
	SIF_PAGE         = 0x0002
	SIF_POS          = 0x0004
	SIF_TRACKPOS     = 0x0010
	SIF_ALL          = SIF_RANGE | SIF_PAGE | SIF_POS | SIF_TRACKPOS

	SWP_NOZORDER   = 0x0004
	SWP_NOACTIVATE = 0x0010
	CC_RGBINIT     = 0x00000001
	CC_FULLOPEN    = 0x00000002

	SRCCOPY = 0x00CC0020

	menuOpen       = 2001
	menuSettings   = 2002
	menuPlayPause  = 2003
	menuToggleKeys = 2004
	menuExit       = 2005

	settingsSave        = 3001
	settingsCancel      = 3002
	settingsReset       = 3003
	settingsSetDefault  = 3004
	settingsAddRule     = 3005
	settingsChooseColor = 3006

	fieldPlayPause  = 3101
	fieldOpen       = 3102
	fieldToggle     = 3103
	fieldFeedback   = 3104
	fieldBgOpacity  = 3105
	ruleHeaderType  = 3201
	ruleHeaderKey   = 3202
	ruleHeaderValue = 3203
	ruleHeaderUnit  = 3204
	ruleHint        = 3205

	ruleTypeBase   = 4000
	ruleKeyBase    = 5000
	ruleValueBase  = 6000
	ruleDeleteBase = 7000
	ruleUnitBase   = 8000
	maxRules       = 100
)

const (
	actionPlayPause = iota + 1
	actionOpen
	actionToggleKeys
)

type POINT struct{ X, Y int32 }
type RECT struct{ Left, Top, Right, Bottom int32 }
type MSG struct {
	HWnd     uintptr
	Message  uint32
	WParam   uintptr
	LParam   uintptr
	Time     uint32
	Pt       POINT
	LPrivate uint32
}
type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}
type PAINTSTRUCT struct {
	Hdc         uintptr
	FErase      int32
	RcPaint     RECT
	FRestore    int32
	FIncUpdate  int32
	RgbReserved [32]byte
}
type KBDLLHOOKSTRUCT struct {
	VkCode      uint32
	ScanCode    uint32
	Flags       uint32
	Time        uint32
	DwExtraInfo uintptr
}
type TRACKMOUSEEVENT struct {
	CbSize      uint32
	DwFlags     uint32
	HwndTrack   uintptr
	DwHoverTime uint32
}
type MINMAXINFO struct {
	PtReserved     POINT
	PtMaxSize      POINT
	PtMaxPosition  POINT
	PtMinTrackSize POINT
	PtMaxTrackSize POINT
}
type SIZE struct{ CX, CY int32 }
type BLENDFUNCTION struct {
	BlendOp             byte
	BlendFlags          byte
	SourceConstantAlpha byte
	AlphaFormat         byte
}
type BITMAPINFOHEADER struct {
	Size          uint32
	Width         int32
	Height        int32
	Planes        uint16
	BitCount      uint16
	Compression   uint32
	SizeImage     uint32
	XPelsPerMeter int32
	YPelsPerMeter int32
	ClrUsed       uint32
	ClrImportant  uint32
}
type BITMAPINFO struct {
	Header BITMAPINFOHEADER
	Colors [1]uint32
}
type SCROLLINFO struct {
	CbSize    uint32
	FMask     uint32
	NMin      int32
	NMax      int32
	NPage     uint32
	NPos      int32
	NTrackPos int32
}
type CHOOSECOLOR struct {
	LStructSize    uint32
	HwndOwner      uintptr
	HInstance      uintptr
	RgbResult      uint32
	LpCustColors   *uint32
	Flags          uint32
	LCustData      uintptr
	LpfnHook       uintptr
	LpTemplateName *uint16
}
type COPYDATASTRUCT struct {
	DwData uintptr
	CbData uint32
	LpData uintptr
}
type MONITORINFO struct {
	CbSize    uint32
	RcMonitor RECT
	RcWork    RECT
	DwFlags   uint32
}
type OPENFILENAME struct {
	LStructSize       uint32
	HwndOwner         uintptr
	HInstance         uintptr
	LpstrFilter       *uint16
	LpstrCustomFilter *uint16
	NMaxCustFilter    uint32
	NFilterIndex      uint32
	LpstrFile         *uint16
	NMaxFile          uint32
	LpstrFileTitle    *uint16
	NMaxFileTitle     uint32
	LpstrInitialDir   *uint16
	LpstrTitle        *uint16
	Flags             uint32
	NFileOffset       uint16
	NFileExtension    uint16
	LpstrDefExt       *uint16
	LCustData         uintptr
	LpfnHook          uintptr
	LpTemplateName    *uint16
	PvReserved        uintptr
	DwReserved        uint32
	FlagsEx           uint32
}

type ShortcutRule struct {
	Kind  string  `json:"kind"`
	Key   string  `json:"key"`
	Value float64 `json:"value"`
}

type Settings struct {
	Rules []ShortcutRule `json:"rules"`

	PlayPauseKey  string `json:"play_pause_key"`
	OpenKey       string `json:"open_key"`
	ToggleKeysKey string `json:"toggle_keys_key"`
	FeedbackMs    int    `json:"feedback_ms"`

	BackgroundColor        string `json:"background_color"`
	BackgroundTransparency int    `json:"background_transparency"`

	WindowX      int32 `json:"window_x"`
	WindowY      int32 `json:"window_y"`
	WindowWidth  int32 `json:"window_width"`
	WindowHeight int32 `json:"window_height"`
	FontSize     int32 `json:"font_size"`

	SettingsWidth  int32 `json:"settings_width"`
	SettingsHeight int32 `json:"settings_height"`
}

type RuleDraft struct {
	Kind      string
	Key       string
	ValueText string
}

type KeySpec struct {
	VK                    uint32
	Ctrl, Alt, Shift, Win bool
}
type ShortcutConfig struct {
	PlayPauseKey  string
	OpenKey       string
	ToggleKeysKey string
	Rules         []ShortcutRule
}

type subtitleLoadResult struct {
	ID       uint64
	Path     string
	Cues     []srt.Cue
	Err      error
	Finished time.Time
}

type Engine struct {
	cues     []srt.Cue
	filePath string
	base     time.Duration
	anchor   time.Time
	playing  bool
	speed    float64
	end      time.Duration
}

func (e *Engine) position() time.Duration {
	p := e.base
	if e.playing {
		p += time.Duration(float64(time.Since(e.anchor)) * e.speed)
	}
	if p < 0 {
		return 0
	}
	if e.end > 0 && p > e.end {
		return e.end
	}
	return p
}
func (e *Engine) snapshot() { e.base = e.position(); e.anchor = time.Now() }
func (e *Engine) toggle() {
	if len(e.cues) == 0 {
		return
	}
	e.snapshot()
	if e.end > 0 && e.base >= e.end {
		e.base = 0
	}
	e.playing = !e.playing
	e.anchor = time.Now()
}
func (e *Engine) seek(delta time.Duration) {
	e.snapshot()
	e.base += delta
	if e.base < 0 {
		e.base = 0
	}
	if e.end > 0 && e.base > e.end {
		e.base = e.end
	}
	e.anchor = time.Now()
}
func (e *Engine) seekTo(position time.Duration) {
	if position < 0 {
		position = 0
	}
	if e.end > 0 && position > e.end {
		position = e.end
	}
	e.base = position
	e.anchor = time.Now()
}
func (e *Engine) setSpeed(v float64) {
	e.snapshot()
	if v < 0.1 {
		v = 0.1
	}
	if v > 10 {
		v = 10
	}
	e.speed = v
	e.anchor = time.Now()
}

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	comdlg32 = syscall.NewLazyDLL("comdlg32.dll")
	dwmapi   = syscall.NewLazyDLL("dwmapi.dll")

	procRegisterClassExW      = user32.NewProc("RegisterClassExW")
	procCreateWindowExW       = user32.NewProc("CreateWindowExW")
	procDefWindowProcW        = user32.NewProc("DefWindowProcW")
	procShowWindow            = user32.NewProc("ShowWindow")
	procUpdateWindow          = user32.NewProc("UpdateWindow")
	procGetMessageW           = user32.NewProc("GetMessageW")
	procTranslateMessage      = user32.NewProc("TranslateMessage")
	procDispatchMessageW      = user32.NewProc("DispatchMessageW")
	procPostQuitMessage       = user32.NewProc("PostQuitMessage")
	procLoadCursorW           = user32.NewProc("LoadCursorW")
	procLoadIconW             = user32.NewProc("LoadIconW")
	procBeginPaint            = user32.NewProc("BeginPaint")
	procEndPaint              = user32.NewProc("EndPaint")
	procGetClientRect         = user32.NewProc("GetClientRect")
	procInvalidateRect        = user32.NewProc("InvalidateRect")
	procSetTimer              = user32.NewProc("SetTimer")
	procKillTimer             = user32.NewProc("KillTimer")
	procSetLayeredWindowAttrs = user32.NewProc("SetLayeredWindowAttributes")
	procUpdateLayeredWindow   = user32.NewProc("UpdateLayeredWindow")
	procGetDC                 = user32.NewProc("GetDC")
	procReleaseDC             = user32.NewProc("ReleaseDC")
	procSetWindowPos          = user32.NewProc("SetWindowPos")
	procSetFocus              = user32.NewProc("SetFocus")
	procSetScrollInfo         = user32.NewProc("SetScrollInfo")
	procGetScrollInfo         = user32.NewProc("GetScrollInfo")
	procCreatePopupMenu       = user32.NewProc("CreatePopupMenu")
	procAppendMenuW           = user32.NewProc("AppendMenuW")
	procTrackPopupMenu        = user32.NewProc("TrackPopupMenu")
	procDestroyMenu           = user32.NewProc("DestroyMenu")
	procGetCursorPos          = user32.NewProc("GetCursorPos")
	procSetForegroundWindow   = user32.NewProc("SetForegroundWindow")
	procFindWindowW           = user32.NewProc("FindWindowW")
	procSendMessageTimeoutW   = user32.NewProc("SendMessageTimeoutW")
	procPostThreadMessageW    = user32.NewProc("PostThreadMessageW")
	procMonitorFromRect       = user32.NewProc("MonitorFromRect")
	procMonitorFromWindow     = user32.NewProc("MonitorFromWindow")
	procGetMonitorInfoW       = user32.NewProc("GetMonitorInfoW")
	procPostMessageW          = user32.NewProc("PostMessageW")
	procSendMessageW          = user32.NewProc("SendMessageW")
	procReleaseCapture        = user32.NewProc("ReleaseCapture")
	procSetCapture            = user32.NewProc("SetCapture")
	procDestroyWindow         = user32.NewProc("DestroyWindow")
	procMessageBoxW           = user32.NewProc("MessageBoxW")
	procGetWindowTextW        = user32.NewProc("GetWindowTextW")
	procSetWindowTextW        = user32.NewProc("SetWindowTextW")
	procGetWindowRect         = user32.NewProc("GetWindowRect")
	procSetWindowsHookExW     = user32.NewProc("SetWindowsHookExW")
	procCallNextHookEx        = user32.NewProc("CallNextHookEx")
	procUnhookWindowsHookEx   = user32.NewProc("UnhookWindowsHookEx")
	procGetAsyncKeyState      = user32.NewProc("GetAsyncKeyState")
	procSetProcessDPIAware    = user32.NewProc("SetProcessDPIAware")
	procTrackMouseEvent       = user32.NewProc("TrackMouseEvent")
	procSetWindowLongPtrW     = user32.NewProc("SetWindowLongPtrW")
	procCallWindowProcW       = user32.NewProc("CallWindowProcW")
	procEnableWindow          = user32.NewProc("EnableWindow")

	procGetStockObject         = gdi32.NewProc("GetStockObject")
	procCreateSolidBrush       = gdi32.NewProc("CreateSolidBrush")
	procDeleteObject           = gdi32.NewProc("DeleteObject")
	procFillRect               = user32.NewProc("FillRect")
	procSetTextColor           = gdi32.NewProc("SetTextColor")
	procSetBkMode              = gdi32.NewProc("SetBkMode")
	procCreateFontW            = gdi32.NewProc("CreateFontW")
	procSelectObject           = gdi32.NewProc("SelectObject")
	procDrawTextW              = user32.NewProc("DrawTextW")
	procCreateCompatibleDC     = gdi32.NewProc("CreateCompatibleDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procCreateDIBSection       = gdi32.NewProc("CreateDIBSection")
	procDeleteDC               = gdi32.NewProc("DeleteDC")
	procBitBlt                 = gdi32.NewProc("BitBlt")
	procPolygon                = gdi32.NewProc("Polygon")

	procGetModuleHandleW      = kernel32.NewProc("GetModuleHandleW")
	procCreateMutexW          = kernel32.NewProc("CreateMutexW")
	procCloseHandle           = kernel32.NewProc("CloseHandle")
	procGetCurrentThreadId    = kernel32.NewProc("GetCurrentThreadId")
	procDragAcceptFiles       = shell32.NewProc("DragAcceptFiles")
	procDragQueryFileW        = shell32.NewProc("DragQueryFileW")
	procDragFinish            = shell32.NewProc("DragFinish")
	procChooseColorW          = comdlg32.NewProc("ChooseColorW")
	procGetOpenFileNameW      = comdlg32.NewProc("GetOpenFileNameW")
	procDwmSetWindowAttribute = dwmapi.NewProc("DwmSetWindowAttribute")
)

var (
	mainWnd       uintptr
	settingsWnd   uintptr
	hInstance     uintptr
	instanceMutex uintptr

	settings Settings
	engine   = Engine{speed: 1.0}
	keyDown  [256]bool

	shortcutsEnabled atomic.Bool
	shortcutConfig   atomic.Value
	settingsOpen     atomic.Bool
	hookHandle       atomic.Uintptr
	hookThreadID     atomic.Uint32
	hookDone         chan struct{}
	feedbackText     string
	feedbackUntil    time.Time
	dialogActive     atomic.Bool
	pendingPathMu    sync.Mutex
	pendingPath      string
	loadSeq          atomic.Uint64
	latestLoadID     atomic.Uint64
	loadResultMu     sync.Mutex
	loadResults      = map[uint64]subtitleLoadResult{}
	controls         = map[int]uintptr{}
	rulesPanel       uintptr
	ruleDrafts       []RuleDraft
	settingsDraft    Settings
	settingsScroll   int32
	bgColorDraft     string
	customColors     [16]uint32

	progressVisible       bool
	trackingMouse         bool
	draggingProgress      bool
	hoverFooterButton     int
	progressKeyboardUntil time.Time
	lastSubtitleText      string

	startupActive              = true
	startupProgress      int32 = 18
	startupLabel               = "正在显示窗口…"
	startupStarted             = time.Now()
	startupHookRequested bool
	startupHookFinished  bool
	startupFinishAt      time.Time

	shortcutEditCallback      uintptr
	settingsProcCallback      uintptr
	rulesPanelCallback        uintptr
	hookCallback              uintptr
	settingsClassesRegistered bool
	editOldProc               = map[uintptr]uintptr{}
)

func ptr(s string) *uint16            { p, _ := syscall.UTF16PtrFromString(s); return p }
func signed32(v int32) uintptr        { return uintptr(uint32(v)) }
func loword(v uintptr) uint16         { return uint16(v & 0xffff) }
func highword(v uintptr) uint16       { return uint16((v >> 16) & 0xffff) }
func xFromLParam(v uintptr) int32     { return int32(int16(uint16(v & 0xffff))) }
func yFromLParam(v uintptr) int32     { return int32(int16(uint16((v >> 16) & 0xffff))) }
func wheelDelta(wParam uintptr) int16 { return int16(uint16((wParam >> 16) & 0xffff)) }

func cloneRules(in []ShortcutRule) []ShortcutRule {
	out := make([]ShortcutRule, len(in))
	copy(out, in)
	return out
}

func refreshShortcutConfig() {
	shortcutConfig.Store(ShortcutConfig{
		PlayPauseKey:  settings.PlayPauseKey,
		OpenKey:       settings.OpenKey,
		ToggleKeysKey: settings.ToggleKeysKey,
		Rules:         cloneRules(settings.Rules),
	})
}

func currentShortcutConfig() ShortcutConfig {
	if v := shortcutConfig.Load(); v != nil {
		return v.(ShortcutConfig)
	}
	return ShortcutConfig{}
}

func defaults() Settings {
	return Settings{
		Rules: []ShortcutRule{
			// The first two seek rules are permanent and drive the footer buttons.
			{Kind: "seek", Key: "Shift+Right", Value: 1},
			{Kind: "seek", Key: "Shift+Left", Value: -1},
			{Kind: "seek", Key: "Left", Value: -5},
			{Kind: "seek", Key: "Right", Value: 5},
			{Kind: "speed_add", Key: "Ctrl+Right", Value: 0.1},
			{Kind: "speed_add", Key: "Ctrl+Left", Value: -0.1},
			{Kind: "speed_set", Key: "S", Value: 1.0},
		},
		FeedbackMs:             900,
		PlayPauseKey:           "Space",
		OpenKey:                "Ctrl+Alt+O",
		ToggleKeysKey:          "Ctrl+Alt+F12",
		BackgroundColor:        "#141414",
		BackgroundTransparency: 18,
		WindowX:                320, WindowY: 720, WindowWidth: 960, WindowHeight: 190, FontSize: 30,
		SettingsWidth: 760, SettingsHeight: 620,
	}
}

func executableDir() string {
	exe, err := os.Executable()
	if err == nil {
		// Avoid resolving symbolic links during startup. The executable path is
		// already sufficient for locating the portable configuration files.
		return filepath.Dir(exe)
	}
	return "."
}
func legacyConfigBase(appFolder string) string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base, _ = os.UserConfigDir()
	}
	return filepath.Join(base, appFolder)
}
func settingsPath() string        { return filepath.Join(executableDir(), "settings.json") }
func defaultSettingsPath() string { return filepath.Join(executableDir(), "default_settings.json") }
func factorySettingsPath() string { return filepath.Join(executableDir(), "factory_settings.json") }
func legacySettingsPath() string {
	return filepath.Join(legacyConfigBase("SRTPlayer"), "settings.json")
}
func legacyDefaultSettingsPath() string {
	return filepath.Join(legacyConfigBase("SRTPlayer"), "default_settings.json")
}
func oldSettingsPath() string {
	return filepath.Join(legacyConfigBase("PenguinSubtitleOverlay"), "settings.json")
}

func clampInt32(v, min, max int32) int32 {
	if v < min {
		return min
	}
	if v > max {
		return max
	}
	return v
}

func sanitizeWindowPlacement(s *Settings) {
	if s.WindowWidth < 480 {
		s.WindowWidth = 480
	}
	if s.WindowHeight < 170 {
		s.WindowHeight = 170
	}
	if s.WindowWidth > 16384 {
		s.WindowWidth = 960
	}
	if s.WindowHeight > 16384 {
		s.WindowHeight = 190
	}
	if s.WindowX < -100000 || s.WindowX > 100000 {
		s.WindowX = 0
	}
	if s.WindowY < -100000 || s.WindowY > 100000 {
		s.WindowY = 0
	}

	r := RECT{Left: s.WindowX, Top: s.WindowY, Right: s.WindowX + s.WindowWidth, Bottom: s.WindowY + s.WindowHeight}
	monitor, _, _ := procMonitorFromRect.Call(uintptr(unsafe.Pointer(&r)), MONITOR_DEFAULTTONEAREST)
	if monitor == 0 {
		return
	}
	mi := MONITORINFO{CbSize: uint32(unsafe.Sizeof(MONITORINFO{}))}
	ok, _, _ := procGetMonitorInfoW.Call(monitor, uintptr(unsafe.Pointer(&mi)))
	if ok == 0 {
		return
	}
	work := mi.RcWork
	maxW := work.Right - work.Left
	maxH := work.Bottom - work.Top
	if maxW <= 0 || maxH <= 0 {
		return
	}
	minW := int32(480)
	minH := int32(170)
	if maxW < minW {
		minW = maxW
	}
	if maxH < minH {
		minH = maxH
	}
	s.WindowWidth = clampInt32(s.WindowWidth, minW, maxW)
	s.WindowHeight = clampInt32(s.WindowHeight, minH, maxH)
	s.WindowX = clampInt32(s.WindowX, work.Left, work.Right-s.WindowWidth)
	s.WindowY = clampInt32(s.WindowY, work.Top, work.Bottom-s.WindowHeight)
}

func backupCorruptSettings(path string) {
	stamp := time.Now().Format("20060102-150405")
	_ = os.Rename(path, path+".corrupt-"+stamp)
}

func createSingleInstance() bool {
	h, _, callErr := procCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(ptr("Local\\SRTPlayer.SingleInstance"))))
	if h == 0 {
		return true
	}
	if callErr == syscall.Errno(ERROR_ALREADY_EXISTS) {
		procCloseHandle.Call(h)
		return false
	}
	instanceMutex = h
	return true
}

func forwardToExisting(path string) bool {
	deadline := time.Now().Add(2500 * time.Millisecond)
	for time.Now().Before(deadline) {
		hwnd, _, _ := procFindWindowW.Call(uintptr(unsafe.Pointer(ptr("SRTPlayerMainClass"))), 0)
		if hwnd != 0 {
			if path != "" {
				if abs, err := filepath.Abs(path); err == nil {
					path = abs
				}
				u16, err := syscall.UTF16FromString(path)
				if err == nil {
					cds := COPYDATASTRUCT{DwData: 1, CbData: uint32(len(u16) * 2), LpData: uintptr(unsafe.Pointer(&u16[0]))}
					var result uintptr
					procSendMessageTimeoutW.Call(hwnd, WM_COPYDATA, 0, uintptr(unsafe.Pointer(&cds)), SMTO_ABORTIFHUNG, 2000, uintptr(unsafe.Pointer(&result)))
				}
			}
			procPostMessageW.Call(hwnd, WM_APP_ACTIVATE, 0, 0)
			return true
		}
		time.Sleep(50 * time.Millisecond)
	}
	return false
}

func normalizeRule(r ShortcutRule) (ShortcutRule, bool) {
	switch r.Kind {
	case "seek":
		if r.Value == 0 || r.Value < -3600 || r.Value > 3600 {
			return r, false
		}
	case "speed_add":
		if r.Value == 0 || r.Value < -5 || r.Value > 5 {
			return r, false
		}
	case "speed_set":
		if r.Value < 0.1 || r.Value > 10 {
			return r, false
		}
	default:
		return r, false
	}
	canonical, err := canonicalShortcut(r.Key)
	if err != nil {
		return r, false
	}
	r.Key = canonical
	return r, true
}

func loadSettingsData(data []byte) Settings {
	s := defaults()
	var raw map[string]json.RawMessage
	_ = json.Unmarshal(data, &raw)
	_ = json.Unmarshal(data, &s)

	if _, ok := raw["rules"]; !ok {
		var legacy struct {
			Seek1Seconds     float64 `json:"seek1_seconds"`
			Seek2Seconds     float64 `json:"seek2_seconds"`
			Speed1Step       float64 `json:"speed1_step"`
			Speed2Step       float64 `json:"speed2_step"`
			Seek1ForwardKey  string  `json:"seek1_forward_key"`
			Seek1BackwardKey string  `json:"seek1_backward_key"`
			Seek2ForwardKey  string  `json:"seek2_forward_key"`
			Seek2BackwardKey string  `json:"seek2_backward_key"`
			Speed1UpKey      string  `json:"speed1_up_key"`
			Speed1DownKey    string  `json:"speed1_down_key"`
			Speed2UpKey      string  `json:"speed2_up_key"`
			Speed2DownKey    string  `json:"speed2_down_key"`
			SeekSeconds      float64 `json:"seek_seconds"`
			SpeedStep        float64 `json:"speed_step"`
			ForwardKey       string  `json:"forward_key"`
			BackwardKey      string  `json:"backward_key"`
			SpeedUpKey       string  `json:"speed_up_key"`
			SpeedDownKey     string  `json:"speed_down_key"`
		}
		_ = json.Unmarshal(data, &legacy)
		seek1 := legacy.Seek1Seconds
		if seek1 <= 0 {
			seek1 = legacy.SeekSeconds
		}
		if seek1 <= 0 {
			seek1 = 1
		}
		seek2 := legacy.Seek2Seconds
		if seek2 <= 0 {
			seek2 = 30
		}
		step1 := legacy.Speed1Step
		if step1 <= 0 {
			step1 = legacy.SpeedStep
		}
		if step1 <= 0 {
			step1 = 0.1
		}
		step2 := legacy.Speed2Step
		if step2 <= 0 {
			step2 = 0.5
		}
		f1 := legacy.Seek1ForwardKey
		if f1 == "" {
			f1 = legacy.ForwardKey
		}
		if f1 == "" {
			f1 = "Right"
		}
		b1 := legacy.Seek1BackwardKey
		if b1 == "" {
			b1 = legacy.BackwardKey
		}
		if b1 == "" {
			b1 = "Left"
		}
		u1 := legacy.Speed1UpKey
		if u1 == "" {
			u1 = legacy.SpeedUpKey
		}
		if u1 == "" {
			u1 = "Ctrl+Right"
		}
		d1 := legacy.Speed1DownKey
		if d1 == "" {
			d1 = legacy.SpeedDownKey
		}
		if d1 == "" {
			d1 = "Ctrl+Left"
		}
		if legacy.Seek2ForwardKey == "" {
			legacy.Seek2ForwardKey = "Shift+Right"
		}
		if legacy.Seek2BackwardKey == "" {
			legacy.Seek2BackwardKey = "Shift+Left"
		}
		if legacy.Speed2UpKey == "" {
			legacy.Speed2UpKey = "Ctrl+Shift+Right"
		}
		if legacy.Speed2DownKey == "" {
			legacy.Speed2DownKey = "Ctrl+Shift+Left"
		}
		s.Rules = []ShortcutRule{
			{Kind: "seek", Key: f1, Value: seek1}, {Kind: "seek", Key: b1, Value: -seek1},
			{Kind: "seek", Key: legacy.Seek2ForwardKey, Value: seek2}, {Kind: "seek", Key: legacy.Seek2BackwardKey, Value: -seek2},
			{Kind: "speed_add", Key: u1, Value: step1}, {Kind: "speed_add", Key: d1, Value: -step1},
			{Kind: "speed_add", Key: legacy.Speed2UpKey, Value: step2}, {Kind: "speed_add", Key: legacy.Speed2DownKey, Value: -step2},
		}
	}
	return normalizeSettings(s)
}

func normalizeSettings(s Settings) Settings {
	d := defaults()
	if s.FeedbackMs < 100 || s.FeedbackMs > 5000 {
		s.FeedbackMs = d.FeedbackMs
	}
	if canonical, err := canonicalShortcut(s.PlayPauseKey); err == nil {
		s.PlayPauseKey = canonical
	} else {
		s.PlayPauseKey = d.PlayPauseKey
	}
	if canonical, err := canonicalShortcut(s.OpenKey); err == nil {
		s.OpenKey = canonical
	} else {
		s.OpenKey = d.OpenKey
	}
	if canonical, err := canonicalShortcut(s.ToggleKeysKey); err == nil {
		s.ToggleKeysKey = canonical
	} else {
		s.ToggleKeysKey = d.ToggleKeysKey
	}
	if !validHexColor(s.BackgroundColor) {
		s.BackgroundColor = d.BackgroundColor
	}
	if s.BackgroundTransparency < 0 || s.BackgroundTransparency > 100 {
		s.BackgroundTransparency = d.BackgroundTransparency
	}
	if s.WindowWidth < 400 {
		s.WindowWidth = d.WindowWidth
	}
	if s.WindowHeight < 170 {
		s.WindowHeight = d.WindowHeight
	}
	if s.FontSize < 12 || s.FontSize > 96 {
		s.FontSize = d.FontSize
	}
	if s.SettingsWidth < 720 {
		s.SettingsWidth = d.SettingsWidth
	}
	if s.SettingsHeight < 520 {
		s.SettingsHeight = d.SettingsHeight
	}
	if len(s.Rules) > maxRules {
		s.Rules = s.Rules[:maxRules]
	}
	clean := make([]ShortcutRule, 0, len(s.Rules))
	for _, r := range s.Rules {
		if nr, ok := normalizeRule(r); ok {
			clean = append(clean, nr)
		}
	}
	// The first two rules are permanent seek rules used by the footer buttons.
	// Preserve valid user values on upgrade, but repair missing or incompatible entries.
	for len(clean) < 2 {
		clean = append(clean, d.Rules[len(clean)])
	}
	if clean[0].Kind != "seek" || clean[0].Value <= 0 {
		clean[0] = d.Rules[0]
	}
	if clean[1].Kind != "seek" || clean[1].Value >= 0 {
		clean[1] = d.Rules[1]
	}
	s.Rules = clean
	return s
}

func loadSettings() Settings {
	if data, err := os.ReadFile(settingsPath()); err == nil {
		if json.Valid(data) {
			return loadSettingsData(data)
		}
		backupCorruptSettings(settingsPath())
	}
	for _, legacyPath := range []string{legacySettingsPath(), oldSettingsPath()} {
		if data, err := os.ReadFile(legacyPath); err == nil && json.Valid(data) {
			s := loadSettingsData(data)
			writeSettings(s)
			return s
		}
	}
	s := defaults()
	writeSettings(s)
	return s
}
func loadUserDefaults() Settings {
	if data, err := os.ReadFile(defaultSettingsPath()); err == nil {
		return loadSettingsData(data)
	}
	if data, err := os.ReadFile(legacyDefaultSettingsPath()); err == nil {
		s := loadSettingsData(data)
		writeUserDefaults(s)
		return s
	}
	if data, err := os.ReadFile(factorySettingsPath()); err == nil {
		return loadSettingsData(data)
	}
	return defaults()
}
func writeSettingsFile(path string, s Settings) {
	_ = os.MkdirAll(filepath.Dir(path), 0o755)
	data, _ := json.MarshalIndent(s, "", "  ")
	tmp := path + ".tmp"
	if os.WriteFile(tmp, data, 0o600) == nil {
		_ = os.Rename(tmp, path)
	}
}
func writeSettings(s Settings)     { writeSettingsFile(settingsPath(), s) }
func writeUserDefaults(s Settings) { writeSettingsFile(defaultSettingsPath(), s) }

func snapshotWindowGeometry(s *Settings) {
	if mainWnd != 0 {
		var r RECT
		procGetWindowRect.Call(mainWnd, uintptr(unsafe.Pointer(&r)))
		s.WindowX, s.WindowY = r.Left, r.Top
		s.WindowWidth, s.WindowHeight = r.Right-r.Left, r.Bottom-r.Top
	}
	if settingsWnd != 0 {
		var r RECT
		procGetWindowRect.Call(settingsWnd, uintptr(unsafe.Pointer(&r)))
		s.SettingsWidth, s.SettingsHeight = r.Right-r.Left, r.Bottom-r.Top
	}
}
func saveSettings() {
	snapshotWindowGeometry(&settings)
	writeSettings(settings)
}

func validHexColor(v string) bool {
	if len(v) != 7 || v[0] != '#' {
		return false
	}
	_, err := strconv.ParseUint(v[1:], 16, 24)
	return err == nil
}
func parseHexColor(v string) (byte, byte, byte) {
	if !validHexColor(v) {
		v = "#141414"
	}
	n, _ := strconv.ParseUint(v[1:], 16, 24)
	return byte(n >> 16), byte(n >> 8), byte(n)
}
func colorRefFromHex(v string) uint32 {
	r, g, b := parseHexColor(v)
	return uint32(r) | uint32(g)<<8 | uint32(b)<<16
}
func hexFromColorRef(c uint32) string {
	r := c & 0xff
	g := (c >> 8) & 0xff
	b := (c >> 16) & 0xff
	return fmt.Sprintf("#%02X%02X%02X", r, g, b)
}

func parseShortcut(value string) (KeySpec, error) {
	var spec KeySpec
	parts := strings.Split(value, "+")
	if len(parts) == 0 {
		return spec, fmt.Errorf("快捷键为空")
	}
	keySeen := false
	for _, raw := range parts {
		p := strings.ToUpper(strings.TrimSpace(raw))
		switch p {
		case "CTRL", "CONTROL":
			spec.Ctrl = true
		case "ALT":
			spec.Alt = true
		case "SHIFT":
			spec.Shift = true
		case "WIN", "WINDOWS":
			spec.Win = true
		default:
			if keySeen {
				return spec, fmt.Errorf("存在多个主按键")
			}
			vk, ok := keyNameToVK(p)
			if !ok {
				return spec, fmt.Errorf("不支持的按键 %q", raw)
			}
			spec.VK, keySeen = vk, true
		}
	}
	if !keySeen {
		return spec, fmt.Errorf("缺少主按键")
	}
	return spec, nil
}

func keyNameToVK(name string) (uint32, bool) {
	names := map[string]uint32{
		"BACKSPACE": VK_BACK, "TAB": VK_TAB, "ENTER": VK_RETURN, "ESC": VK_ESCAPE,
		"ESCAPE": VK_ESCAPE, "SPACE": VK_SPACE, "PAUSE": VK_PAUSE, "CAPSLOCK": VK_CAPITAL,
		"PAGEUP": VK_PRIOR, "PAGEDOWN": VK_NEXT, "END": VK_END, "HOME": VK_HOME,
		"LEFT": VK_LEFT, "UP": VK_UP, "RIGHT": VK_RIGHT, "DOWN": VK_DOWN,
		"PRINTSCREEN": VK_SNAPSHOT, "INSERT": VK_INSERT, "DELETE": VK_DELETE,
		"MENU": VK_APPS, "NUMLOCK": VK_NUMLOCK, "SCROLLLOCK": VK_SCROLL,
		"MULTIPLY": VK_MULTIPLY, "ADD": VK_ADD, "SUBTRACT": VK_SUBTRACT,
		"DECIMAL": VK_DECIMAL, "DIVIDE": VK_DIVIDE,
		"SEMICOLON": VK_OEM_1, "PLUS": VK_OEM_PLUS, "COMMA": VK_OEM_COMMA,
		"MINUS": VK_OEM_MINUS, "PERIOD": VK_OEM_PERIOD, "SLASH": VK_OEM_2,
		"BACKTICK": VK_OEM_3, "LEFTBRACKET": VK_OEM_4, "BACKSLASH": VK_OEM_5,
		"RIGHTBRACKET": VK_OEM_6, "QUOTE": VK_OEM_7,
	}
	if v, ok := names[name]; ok {
		return v, true
	}
	if len(name) == 1 {
		c := name[0]
		if (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') {
			return uint32(c), true
		}
	}
	if strings.HasPrefix(name, "F") {
		n, err := strconv.Atoi(strings.TrimPrefix(name, "F"))
		if err == nil && n >= 1 && n <= 24 {
			return uint32(0x6F + n), true
		}
	}
	if strings.HasPrefix(name, "NUMPAD") {
		n, err := strconv.Atoi(strings.TrimPrefix(name, "NUMPAD"))
		if err == nil && n >= 0 && n <= 9 {
			return uint32(VK_NUMPAD0 + n), true
		}
	}
	if strings.HasPrefix(name, "VK_") {
		v, err := strconv.ParseUint(strings.TrimPrefix(name, "VK_"), 16, 8)
		if err == nil {
			return uint32(v), true
		}
	}
	return 0, false
}

func vkToName(vk uint32) string {
	names := map[uint32]string{
		VK_BACK: "Backspace", VK_TAB: "Tab", VK_RETURN: "Enter", VK_ESCAPE: "Esc",
		VK_SPACE: "Space", VK_PAUSE: "Pause", VK_CAPITAL: "CapsLock", VK_PRIOR: "PageUp",
		VK_NEXT: "PageDown", VK_END: "End", VK_HOME: "Home", VK_LEFT: "Left", VK_UP: "Up",
		VK_RIGHT: "Right", VK_DOWN: "Down", VK_SNAPSHOT: "PrintScreen", VK_INSERT: "Insert",
		VK_DELETE: "Delete", VK_APPS: "Menu", VK_NUMLOCK: "NumLock", VK_SCROLL: "ScrollLock",
		VK_MULTIPLY: "Multiply", VK_ADD: "Add", VK_SUBTRACT: "Subtract", VK_DECIMAL: "Decimal",
		VK_DIVIDE: "Divide", VK_OEM_1: "Semicolon", VK_OEM_PLUS: "Plus", VK_OEM_COMMA: "Comma",
		VK_OEM_MINUS: "Minus", VK_OEM_PERIOD: "Period", VK_OEM_2: "Slash", VK_OEM_3: "Backtick",
		VK_OEM_4: "LeftBracket", VK_OEM_5: "Backslash", VK_OEM_6: "RightBracket", VK_OEM_7: "Quote",
	}
	if n, ok := names[vk]; ok {
		return n
	}
	if (vk >= 'A' && vk <= 'Z') || (vk >= '0' && vk <= '9') {
		return string(rune(vk))
	}
	if vk >= 0x70 && vk <= 0x87 {
		return fmt.Sprintf("F%d", vk-0x6F)
	}
	if vk >= VK_NUMPAD0 && vk <= VK_NUMPAD0+9 {
		return fmt.Sprintf("Numpad%d", vk-VK_NUMPAD0)
	}
	return fmt.Sprintf("VK_%02X", vk)
}

func shortcutString(spec KeySpec) string {
	var parts []string
	if spec.Ctrl {
		parts = append(parts, "Ctrl")
	}
	if spec.Alt {
		parts = append(parts, "Alt")
	}
	if spec.Shift {
		parts = append(parts, "Shift")
	}
	if spec.Win {
		parts = append(parts, "Win")
	}
	parts = append(parts, vkToName(spec.VK))
	return strings.Join(parts, "+")
}
func canonicalShortcut(value string) (string, error) {
	spec, err := parseShortcut(value)
	if err != nil {
		return "", err
	}
	return shortcutString(spec), nil
}
func modifierDown(vk uintptr) bool {
	r, _, _ := procGetAsyncKeyState.Call(vk)
	return int16(r&0xffff) < 0
}
func matches(value string, vk uint32) bool {
	spec, err := parseShortcut(value)
	if err != nil || spec.VK != vk {
		return false
	}
	winDown := modifierDown(VK_LWIN) || modifierDown(VK_RWIN)
	return spec.Ctrl == modifierDown(VK_CONTROL) && spec.Alt == modifierDown(VK_MENU) && spec.Shift == modifierDown(VK_SHIFT) && spec.Win == winDown
}
func isModifier(vk uint32) bool {
	return vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU || vk == VK_LWIN || vk == VK_RWIN
}

func keyboardProc(nCode int, wParam uintptr, lParam uintptr) uintptr {
	if nCode == HC_ACTION {
		k := (*KBDLLHOOKSTRUCT)(unsafe.Pointer(lParam))
		vk := k.VkCode
		if vk < 256 {
			if wParam == WM_KEYUP || wParam == WM_SYSKEYUP {
				keyDown[vk] = false
			} else if wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN {
				wasDown := keyDown[vk]
				keyDown[vk] = true
				if !settingsOpen.Load() && !dialogActive.Load() {
					cfg := currentShortcutConfig()
					if !wasDown && matches(cfg.ToggleKeysKey, vk) {
						procPostMessageW.Call(mainWnd, WM_APP_ACTION, uintptr(actionToggleKeys), 0)
					} else if shortcutsEnabled.Load() {
						fixed := 0
						if !wasDown {
							switch {
							case matches(cfg.PlayPauseKey, vk):
								fixed = actionPlayPause
							case matches(cfg.OpenKey, vk):
								fixed = actionOpen
							}
						}
						if fixed != 0 {
							procPostMessageW.Call(mainWnd, WM_APP_ACTION, uintptr(fixed), 0)
						} else {
							for i, rule := range cfg.Rules {
								if matches(rule.Key, vk) {
									// Seek rules intentionally follow Windows key-repeat events.
									// Speed rules fire once to avoid runaway multiplier changes.
									if !wasDown || rule.Kind == "seek" {
										procPostMessageW.Call(mainWnd, WM_APP_RULE, uintptr(i), 0)
									}
									break
								}
							}
						}
					}
				}
			}
		}
	}
	r, _, _ := procCallNextHookEx.Call(hookHandle.Load(), uintptr(nCode), wParam, lParam)
	return r
}

func startKeyboardHookThread() {
	hookDone = make(chan struct{})
	go func() {
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()
		defer close(hookDone)

		tid, _, _ := procGetCurrentThreadId.Call()
		hookThreadID.Store(uint32(tid))
		h, _, _ := procSetWindowsHookExW.Call(WH_KEYBOARD_LL, hookCallback, hInstance, 0)
		if h == 0 {
			procPostMessageW.Call(mainWnd, WM_APP_HOOK_STATUS, 0, 0)
			hookThreadID.Store(0)
			return
		}
		hookHandle.Store(h)
		procPostMessageW.Call(mainWnd, WM_APP_HOOK_STATUS, 1, 0)

		var msg MSG
		for {
			r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
			if int32(r) <= 0 {
				break
			}
			procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
			procDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
		}
		if old := hookHandle.Swap(0); old != 0 {
			procUnhookWindowsHookEx.Call(old)
		}
		hookThreadID.Store(0)
	}()
}

func stopKeyboardHookThread() {
	if tid := hookThreadID.Load(); tid != 0 {
		procPostThreadMessageW.Call(uintptr(tid), WM_QUIT, 0, 0)
	}
	if hookDone != nil {
		select {
		case <-hookDone:
		case <-time.After(750 * time.Millisecond):
		}
	}
}

func showFeedback(text string) {
	feedbackText = text
	feedbackUntil = time.Now().Add(time.Duration(settings.FeedbackMs) * time.Millisecond)
	procInvalidateRect.Call(mainWnd, 0, 0)
}

func startSubtitleLoad(path string) {
	path = strings.TrimSpace(path)
	if path == "" {
		return
	}
	if strings.ToLower(filepath.Ext(path)) != ".srt" {
		message(mainWnd, "只支持 SRT 字幕文件。", "无法打开")
		return
	}
	if abs, err := filepath.Abs(path); err == nil {
		path = abs
	}
	id := loadSeq.Add(1)
	latestLoadID.Store(id)
	showFeedback("正在加载字幕…")
	go func(loadID uint64, filePath string) {
		cues, err := srt.ParseFile(filePath)
		result := subtitleLoadResult{ID: loadID, Path: filePath, Cues: cues, Err: err, Finished: time.Now()}
		loadResultMu.Lock()
		loadResults[loadID] = result
		loadResultMu.Unlock()
		procPostMessageW.Call(mainWnd, WM_APP_SRT_LOADED, uintptr(loadID), 0)
	}(id, path)
}

func applySubtitleLoad(id uint64) {
	loadResultMu.Lock()
	result, ok := loadResults[id]
	delete(loadResults, id)
	loadResultMu.Unlock()
	if !ok || id != latestLoadID.Load() {
		return
	}
	if result.Err != nil {
		message(mainWnd, result.Err.Error(), "读取失败")
		return
	}
	if len(result.Cues) == 0 {
		message(mainWnd, "没有识别到有效的 SRT 时间轴。请确认文件为 UTF-8 编码。", "解析失败")
		return
	}
	engine = Engine{cues: result.Cues, filePath: result.Path, speed: 1.0, end: srt.End(result.Cues), anchor: time.Now()}
	lastSubtitleText = ""
	showFeedback(fmt.Sprintf("已加载 %s · %d 条", filepath.Base(result.Path), len(result.Cues)))
	procInvalidateRect.Call(mainWnd, 0, 0)
}

func executeRule(index int) {
	if index < 0 || index >= len(settings.Rules) || len(engine.cues) == 0 {
		return
	}
	rule := settings.Rules[index]
	switch rule.Kind {
	case "seek":
		engine.seek(time.Duration(rule.Value * float64(time.Second)))
		d := time.Duration(settings.FeedbackMs) * time.Millisecond
		if d < 650*time.Millisecond {
			d = 650 * time.Millisecond
		}
		progressKeyboardUntil = time.Now().Add(d)
		showFeedback(fmt.Sprintf("%+.1f s · %s", rule.Value, formatPosition(engine.position())))
	case "speed_add":
		engine.setSpeed(engine.speed + rule.Value)
		showFeedback(fmt.Sprintf("速度 %.2f 倍", engine.speed))
	case "speed_set":
		engine.setSpeed(rule.Value)
		showFeedback(fmt.Sprintf("速度 %.2f 倍", engine.speed))
	}
}

func executeAction(action int) {
	switch action {
	case actionPlayPause:
		if len(engine.cues) == 0 {
			return
		}
		engine.toggle()
		if engine.playing {
			showFeedback("播放")
		} else {
			showFeedback("暂停")
		}
	case actionOpen:
		openFileDialog()
	case actionToggleKeys:
		enabled := !shortcutsEnabled.Load()
		shortcutsEnabled.Store(enabled)
		if enabled {
			showFeedback("快捷键已启用")
		} else {
			showFeedback("快捷键已停用")
		}
	}
}

func formatPosition(d time.Duration) string {
	if d < 0 {
		d = 0
	}
	total := int64(d / time.Second)
	return fmt.Sprintf("%02d:%02d:%02d", total/3600, (total/60)%60, total%60)
}

func utf16Filter(parts ...string) []uint16 {
	var out []uint16
	for _, part := range parts {
		for _, r := range part {
			if r <= 0xFFFF {
				out = append(out, uint16(r))
			} else {
				r1, r2 := utf16.EncodeRune(r)
				out = append(out, uint16(r1), uint16(r2))
			}
		}
		out = append(out, 0)
	}
	return append(out, 0)
}

func openFileDialog() {
	if dialogActive.Swap(true) {
		return
	}
	go func() {
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()
		defer dialogActive.Store(false)

		fileBuffer := make([]uint16, 32768)
		filter := utf16Filter("SRT 字幕 (*.srt)", "*.srt", "所有文件 (*.*)", "*.*")
		title := ptr("打开 SRT 字幕")
		defExt := ptr("srt")
		ofn := OPENFILENAME{
			LStructSize:  uint32(unsafe.Sizeof(OPENFILENAME{})),
			HwndOwner:    mainWnd,
			HInstance:    hInstance,
			LpstrFilter:  &filter[0],
			NFilterIndex: 1,
			LpstrFile:    &fileBuffer[0],
			NMaxFile:     uint32(len(fileBuffer)),
			LpstrTitle:   title,
			Flags:        OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR,
			LpstrDefExt:  defExt,
		}
		ok, _, _ := procGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&ofn)))
		if ok != 0 {
			path := syscall.UTF16ToString(fileBuffer)
			if path != "" {
				pendingPathMu.Lock()
				pendingPath = path
				pendingPathMu.Unlock()
				procPostMessageW.Call(mainWnd, WM_APP_OPEN_RESULT, 0, 0)
			}
		}
	}()
}

func message(owner uintptr, text, title string) {
	procMessageBoxW.Call(owner, uintptr(unsafe.Pointer(ptr(text))), uintptr(unsafe.Pointer(ptr(title))), 0x00000040)
}

func fillColor(dc uintptr, r RECT, color uintptr) {
	brush, _, _ := procCreateSolidBrush.Call(color)
	procFillRect.Call(dc, uintptr(unsafe.Pointer(&r)), brush)
	procDeleteObject.Call(brush)
}

const (
	progressFooterHeight  int32 = 76
	footerButtonNone            = 0
	footerButtonBackward        = 1
	footerButtonPlayPause       = 2
	footerButtonForward         = 3
)

func subtitleTextRect(client RECT, hasSubtitle bool) RECT {
	r := client
	r.Left += 28
	r.Right -= 28
	r.Top += 20
	r.Bottom -= 18
	if hasSubtitle {
		r.Bottom = client.Bottom - progressFooterHeight
	}
	if r.Bottom < r.Top+20 {
		r.Bottom = r.Top + 20
	}
	return r
}
func progressButtonRects(client RECT) (RECT, RECT, RECT) {
	const size int32 = 28
	const gap int32 = 7
	left := int32(20)
	top := client.Bottom - 35
	back := RECT{Left: left, Top: top, Right: left + size, Bottom: top + size}
	play := RECT{Left: back.Right + gap, Top: top, Right: back.Right + gap + size, Bottom: top + size}
	forward := RECT{Left: play.Right + gap, Top: top, Right: play.Right + gap + size, Bottom: top + size}
	return back, play, forward
}
func progressTrackRect(client RECT) RECT {
	_, _, forward := progressButtonRects(client)
	left := forward.Right + 18
	right := client.Right - 28
	if right < left+40 {
		right = left + 40
	}
	return RECT{Left: left, Top: client.Bottom - 19, Right: right, Bottom: client.Bottom - 12}
}
func progressFraction() float64 {
	if engine.end <= 0 {
		return 0
	}
	fraction := float64(engine.position()) / float64(engine.end)
	if fraction < 0 {
		return 0
	}
	if fraction > 1 {
		return 1
	}
	return fraction
}
func progressThumbRect(client RECT) RECT {
	track := progressTrackRect(client)
	thumbX := track.Left + int32(float64(track.Right-track.Left)*progressFraction())
	return RECT{Left: thumbX - 5, Top: track.Top - 5, Right: thumbX + 5, Bottom: track.Bottom + 5}
}
func progressShouldShow() bool {
	return progressVisible || (!progressKeyboardUntil.IsZero() && time.Now().Before(progressKeyboardUntil))
}
func progressHitTest(client RECT, x, y int32) bool {
	// Keep the active area identical to the visible track and thumb.
	return inRect(x, y, progressTrackRect(client)) || inRect(x, y, progressThumbRect(client))
}
func footerButtonHitTest(client RECT, x, y int32) int {
	back, play, forward := progressButtonRects(client)
	switch {
	case inRect(x, y, back):
		return footerButtonBackward
	case inRect(x, y, play):
		return footerButtonPlayPause
	case inRect(x, y, forward):
		return footerButtonForward
	default:
		return footerButtonNone
	}
}
func inRect(x, y int32, r RECT) bool {
	return x >= r.Left && x <= r.Right && y >= r.Top && y <= r.Bottom
}
func seekFromMouse(x int32) {
	if len(engine.cues) == 0 || engine.end <= 0 {
		return
	}
	var client RECT
	procGetClientRect.Call(mainWnd, uintptr(unsafe.Pointer(&client)))
	track := progressTrackRect(client)
	if x < track.Left {
		x = track.Left
	}
	if x > track.Right {
		x = track.Right
	}
	width := track.Right - track.Left
	if width <= 0 {
		return
	}
	fraction := float64(x-track.Left) / float64(width)
	engine.seekTo(time.Duration(fraction * float64(engine.end)))
	feedbackText = fmt.Sprintf("%s / %s", formatPosition(engine.position()), formatPosition(engine.end))
	feedbackUntil = time.Now().Add(time.Duration(settings.FeedbackMs) * time.Millisecond)
	procInvalidateRect.Call(mainWnd, 0, 0)
}
func drawTriangle(dc uintptr, points []POINT, color uintptr) {
	if len(points) < 3 {
		return
	}
	brush, _, _ := procCreateSolidBrush.Call(color)
	oldBrush, _, _ := procSelectObject.Call(dc, brush)
	nullPen, _, _ := procGetStockObject.Call(8) // NULL_PEN
	oldPen, _, _ := procSelectObject.Call(dc, nullPen)
	procPolygon.Call(dc, uintptr(unsafe.Pointer(&points[0])), uintptr(len(points)))
	procSelectObject.Call(dc, oldPen)
	procSelectObject.Call(dc, oldBrush)
	procDeleteObject.Call(brush)
}
func drawFooterButton(dc uintptr, r RECT, kind int, hovered bool) {
	bg := uintptr(0x003A3A3A)
	if hovered {
		bg = 0x00575757
	}
	fillColor(dc, r, bg)
	color := uintptr(0x00F2F2F2)
	cx := (r.Left + r.Right) / 2
	cy := (r.Top + r.Bottom) / 2
	switch kind {
	case footerButtonBackward:
		drawTriangle(dc, []POINT{{X: cx + 2, Y: cy - 7}, {X: cx + 2, Y: cy + 7}, {X: cx - 7, Y: cy}}, color)
	case footerButtonForward:
		drawTriangle(dc, []POINT{{X: cx - 2, Y: cy - 7}, {X: cx - 2, Y: cy + 7}, {X: cx + 7, Y: cy}}, color)
	case footerButtonPlayPause:
		if engine.playing {
			fillColor(dc, RECT{Left: cx - 6, Top: cy - 7, Right: cx - 2, Bottom: cy + 7}, color)
			fillColor(dc, RECT{Left: cx + 2, Top: cy - 7, Right: cx + 6, Bottom: cy + 7}, color)
		} else {
			drawTriangle(dc, []POINT{{X: cx - 5, Y: cy - 8}, {X: cx - 5, Y: cy + 8}, {X: cx + 7, Y: cy}}, color)
		}
	}
}
func drawProgress(dc uintptr, client RECT) {
	if !progressShouldShow() || len(engine.cues) == 0 || engine.end <= 0 {
		return
	}
	back, play, forward := progressButtonRects(client)
	drawFooterButton(dc, back, footerButtonBackward, hoverFooterButton == footerButtonBackward)
	drawFooterButton(dc, play, footerButtonPlayPause, hoverFooterButton == footerButtonPlayPause)
	drawFooterButton(dc, forward, footerButtonForward, hoverFooterButton == footerButtonForward)

	track := progressTrackRect(client)
	fillColor(dc, track, 0x00505050)
	position := engine.position()
	fraction := progressFraction()
	fill := track
	fill.Right = fill.Left + int32(float64(track.Right-track.Left)*fraction)
	fillColor(dc, fill, 0x00E0E0E0)
	fillColor(dc, progressThumbRect(client), 0x00FFFFFF)

	fontName := ptr("Microsoft YaHei UI")
	font, _, _ := procCreateFontW.Call(signed32(-15), 0, 0, 0, FW_NORMAL, 0, 0, 0, 1, 0, 0, 4, 0, uintptr(unsafe.Pointer(fontName)))
	old, _, _ := procSelectObject.Call(dc, font)
	procSetTextColor.Call(dc, 0x00D8D8D8)
	label := fmt.Sprintf("%s / %s", formatPosition(position), formatPosition(engine.end))
	r := RECT{Left: track.Left, Top: client.Bottom - 58, Right: track.Right, Bottom: client.Bottom - 33}
	procDrawTextW.Call(dc, uintptr(unsafe.Pointer(ptr(label))), ^uintptr(0), uintptr(unsafe.Pointer(&r)), DT_CENTER|DT_SINGLELINE|DT_NOPREFIX)
	procSelectObject.Call(dc, old)
	procDeleteObject.Call(font)
}

func drawStartupOverlay(dc uintptr, client RECT) {
	progress := startupProgress
	if progress < 0 {
		progress = 0
	}
	if progress > 100 {
		progress = 100
	}

	fontName := ptr("Microsoft YaHei UI")
	titleFont, _, _ := procCreateFontW.Call(signed32(-22), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, 1, 0, 0, 4, 0, uintptr(unsafe.Pointer(fontName)))
	oldFont, _, _ := procSelectObject.Call(dc, titleFont)
	procSetTextColor.Call(dc, 0x00F4F4F4)
	label := startupLabel
	if label == "" {
		label = "正在启动…"
	}
	textRect := RECT{Left: client.Left + 28, Top: client.Top + 38, Right: client.Right - 28, Bottom: client.Top + 78}
	procDrawTextW.Call(dc, uintptr(unsafe.Pointer(ptr(label))), ^uintptr(0), uintptr(unsafe.Pointer(&textRect)), DT_CENTER|DT_SINGLELINE|DT_NOPREFIX)
	procSelectObject.Call(dc, oldFont)
	procDeleteObject.Call(titleFont)

	barWidth := client.Right - client.Left - 120
	if barWidth > 520 {
		barWidth = 520
	}
	if barWidth < 180 {
		barWidth = 180
	}
	barLeft := client.Left + (client.Right-client.Left-barWidth)/2
	barTop := client.Top + 98
	if barTop+10 > client.Bottom-28 {
		barTop = client.Bottom - 38
	}
	track := RECT{Left: barLeft, Top: barTop, Right: barLeft + barWidth, Bottom: barTop + 9}
	fillColor(dc, track, 0x00474747)
	filled := track
	filled.Right = filled.Left + int32(float64(track.Right-track.Left)*float64(progress)/100.0)
	if filled.Right > filled.Left {
		fillColor(dc, filled, 0x00FF952A)
	}

	percentFont, _, _ := procCreateFontW.Call(signed32(-15), 0, 0, 0, FW_NORMAL, 0, 0, 0, 1, 0, 0, 4, 0, uintptr(unsafe.Pointer(fontName)))
	oldFont, _, _ = procSelectObject.Call(dc, percentFont)
	procSetTextColor.Call(dc, 0x00D8D8D8)
	percentText := fmt.Sprintf("%d%%", progress)
	percentRect := RECT{Left: barLeft, Top: track.Bottom + 9, Right: barLeft + barWidth, Bottom: track.Bottom + 35}
	procDrawTextW.Call(dc, uintptr(unsafe.Pointer(ptr(percentText))), ^uintptr(0), uintptr(unsafe.Pointer(&percentRect)), DT_CENTER|DT_SINGLELINE|DT_NOPREFIX)
	procSelectObject.Call(dc, oldFont)
	procDeleteObject.Call(percentFont)
}

func setStartupStage(progress int32, label string) {
	if !startupActive {
		return
	}
	if progress > startupProgress {
		startupProgress = progress
	}
	if label != "" {
		startupLabel = label
	}
	if mainWnd != 0 {
		procInvalidateRect.Call(mainWnd, 0, 0)
	}
}

func markStartupComplete(label string) {
	if !startupActive {
		return
	}
	startupProgress = 100
	if label == "" {
		label = "启动完成"
	}
	startupLabel = label
	startupFinishAt = time.Now().Add(180 * time.Millisecond)
	if mainWnd != 0 {
		procInvalidateRect.Call(mainWnd, 0, 0)
	}
}

func drawFittedSubtitle(dc uintptr, text string, area RECT, preferredSize int32) {
	if text == "" || area.Right <= area.Left || area.Bottom <= area.Top {
		return
	}
	fontName := ptr("Microsoft YaHei UI")
	maxHeight := area.Bottom - area.Top
	width := area.Right - area.Left
	if preferredSize < 12 {
		preferredSize = 12
	}
	if preferredSize > 96 {
		preferredSize = 96
	}
	chosenSize := preferredSize
	var measured RECT
	for size := preferredSize; size >= 8; size-- {
		font, _, _ := procCreateFontW.Call(signed32(-size), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, 1, 0, 0, 4, 0, uintptr(unsafe.Pointer(fontName)))
		old, _, _ := procSelectObject.Call(dc, font)
		calc := RECT{Left: 0, Top: 0, Right: width, Bottom: 0}
		procDrawTextW.Call(dc, uintptr(unsafe.Pointer(ptr(text))), ^uintptr(0), uintptr(unsafe.Pointer(&calc)), DT_CENTER|DT_WORDBREAK|DT_NOPREFIX|DT_CALCRECT)
		procSelectObject.Call(dc, old)
		procDeleteObject.Call(font)
		measured = calc
		chosenSize = size
		if calc.Bottom-calc.Top <= maxHeight {
			break
		}
	}
	font, _, _ := procCreateFontW.Call(signed32(-chosenSize), 0, 0, 0, FW_SEMIBOLD, 0, 0, 0, 1, 0, 0, 4, 0, uintptr(unsafe.Pointer(fontName)))
	old, _, _ := procSelectObject.Call(dc, font)
	height := measured.Bottom - measured.Top
	r := area
	r.Top = area.Top + (maxHeight-height)/2
	if r.Top < area.Top {
		r.Top = area.Top
	}
	r.Bottom = area.Bottom
	procDrawTextW.Call(dc, uintptr(unsafe.Pointer(ptr(text))), ^uintptr(0), uintptr(unsafe.Pointer(&r)), DT_CENTER|DT_WORDBREAK|DT_NOPREFIX)
	procSelectObject.Call(dc, old)
	procDeleteObject.Call(font)
}

func renderLayeredWindow(hwnd uintptr) {
	var window RECT
	procGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&window)))
	width := window.Right - window.Left
	height := window.Bottom - window.Top
	if width <= 0 || height <= 0 {
		return
	}

	screenDC, _, _ := procGetDC.Call(0)
	if screenDC == 0 {
		return
	}
	defer procReleaseDC.Call(0, screenDC)
	memDC, _, _ := procCreateCompatibleDC.Call(screenDC)
	if memDC == 0 {
		return
	}
	defer procDeleteDC.Call(memDC)

	bmi := BITMAPINFO{Header: BITMAPINFOHEADER{Size: uint32(unsafe.Sizeof(BITMAPINFOHEADER{})), Width: width, Height: -height, Planes: 1, BitCount: 32, Compression: BI_RGB}}
	var bits uintptr
	bitmap, _, _ := procCreateDIBSection.Call(screenDC, uintptr(unsafe.Pointer(&bmi)), DIB_RGB_COLORS, uintptr(unsafe.Pointer(&bits)), 0, 0)
	if bitmap == 0 || bits == 0 {
		return
	}
	oldBitmap, _, _ := procSelectObject.Call(memDC, bitmap)
	defer func() {
		procSelectObject.Call(memDC, oldBitmap)
		procDeleteObject.Call(bitmap)
	}()

	r, g, b := parseHexColor(settings.BackgroundColor)
	bgRGB := uint32(b) | uint32(g)<<8 | uint32(r)<<16
	pixels := unsafe.Slice((*uint32)(unsafe.Pointer(bits)), int(width*height))
	for i := range pixels {
		pixels[i] = bgRGB
	}

	client := RECT{Left: 0, Top: 0, Right: width, Bottom: height}
	procSetBkMode.Call(memDC, TRANSPARENT)
	procSetTextColor.Call(memDC, 0x00FFFFFF)
	if startupActive {
		drawStartupOverlay(memDC, client)
	} else {
		text := ""
		if len(engine.cues) == 0 {
			text = "将 SRT 拖到这里，或右键打开"
		} else {
			text = srt.At(engine.cues, engine.position())
		}
		lastSubtitleText = text
		drawFittedSubtitle(memDC, text, subtitleTextRect(client, len(engine.cues) > 0), settings.FontSize)
		drawProgress(memDC, client)
	}

	if !startupActive && feedbackText != "" && time.Now().Before(feedbackUntil) {
		fontName := ptr("Microsoft YaHei UI")
		small, _, _ := procCreateFontW.Call(signed32(-17), 0, 0, 0, FW_NORMAL, 0, 0, 0, 1, 0, 0, 4, 0, uintptr(unsafe.Pointer(fontName)))
		old, _, _ := procSelectObject.Call(memDC, small)
		procSetTextColor.Call(memDC, 0x00D8D8D8)
		fr := client
		fr.Left += 16
		fr.Right -= 16
		fr.Top += 10
		fr.Bottom = fr.Top + 24
		procDrawTextW.Call(memDC, uintptr(unsafe.Pointer(ptr(feedbackText))), ^uintptr(0), uintptr(unsafe.Pointer(&fr)), DT_RIGHT|DT_SINGLELINE|DT_NOPREFIX)
		procSelectObject.Call(memDC, old)
		procDeleteObject.Call(small)
	}

	bgAlpha := uint32((100 - settings.BackgroundTransparency) * 255 / 100)
	if bgAlpha == 0 {
		bgAlpha = 1
	}
	for i, px := range pixels {
		rgb := px & 0x00FFFFFF
		if rgb == bgRGB {
			pixels[i] = rgb | bgAlpha<<24
		} else {
			pixels[i] = rgb | 0xFF000000
		}
	}

	dst := POINT{X: window.Left, Y: window.Top}
	sz := SIZE{CX: width, CY: height}
	src := POINT{}
	blend := BLENDFUNCTION{BlendOp: AC_SRC_OVER, SourceConstantAlpha: 255, AlphaFormat: AC_SRC_ALPHA}
	procUpdateLayeredWindow.Call(hwnd, screenDC, uintptr(unsafe.Pointer(&dst)), uintptr(unsafe.Pointer(&sz)), memDC, uintptr(unsafe.Pointer(&src)), 0, uintptr(unsafe.Pointer(&blend)), ULW_ALPHA)
}

func drawWindow(hwnd uintptr) {
	var ps PAINTSTRUCT
	procBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	procEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	renderLayeredWindow(hwnd)
}

func showContextMenu(hwnd uintptr) {
	menu, _, _ := procCreatePopupMenu.Call()
	procAppendMenuW.Call(menu, MF_STRING, menuOpen, uintptr(unsafe.Pointer(ptr("打开 SRT…"))))
	procAppendMenuW.Call(menu, MF_STRING, menuSettings, uintptr(unsafe.Pointer(ptr("设置…"))))
	procAppendMenuW.Call(menu, MF_SEPARATOR, 0, 0)
	procAppendMenuW.Call(menu, MF_STRING, menuPlayPause, uintptr(unsafe.Pointer(ptr("播放 / 暂停"))))
	keyLabel := "停用全局快捷键"
	if !shortcutsEnabled.Load() {
		keyLabel = "启用全局快捷键"
	}
	procAppendMenuW.Call(menu, MF_STRING, menuToggleKeys, uintptr(unsafe.Pointer(ptr(keyLabel))))
	procAppendMenuW.Call(menu, MF_SEPARATOR, 0, 0)
	procAppendMenuW.Call(menu, MF_STRING, menuExit, uintptr(unsafe.Pointer(ptr("退出"))))
	var p POINT
	procGetCursorPos.Call(uintptr(unsafe.Pointer(&p)))
	procSetForegroundWindow.Call(hwnd)
	cmd, _, _ := procTrackPopupMenu.Call(menu, TPM_RIGHTBUTTON|TPM_RETURNCMD, uintptr(p.X), uintptr(p.Y), 0, hwnd, 0)
	procDestroyMenu.Call(menu)
	switch cmd {
	case menuOpen:
		executeAction(actionOpen)
	case menuSettings:
		openSettingsWindow()
	case menuPlayPause:
		executeAction(actionPlayPause)
	case menuToggleKeys:
		executeAction(actionToggleKeys)
	case menuExit:
		procDestroyWindow.Call(hwnd)
	}
}

func mainWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		mainWnd = hwnd
		procSetTimer.Call(hwnd, 1, 50, 0)
		procDragAcceptFiles.Call(hwnd, 1)
		return 0
	case WM_GETMINMAXINFO:
		mmi := (*MINMAXINFO)(unsafe.Pointer(lParam))
		mmi.PtMinTrackSize.X = 480
		mmi.PtMinTrackSize.Y = 170
		monitor, _, _ := procMonitorFromWindow.Call(hwnd, MONITOR_DEFAULTTONEAREST)
		if monitor != 0 {
			mi := MONITORINFO{CbSize: uint32(unsafe.Sizeof(MONITORINFO{}))}
			if ok, _, _ := procGetMonitorInfoW.Call(monitor, uintptr(unsafe.Pointer(&mi))); ok != 0 {
				mmi.PtMaxTrackSize.X = mi.RcWork.Right - mi.RcWork.Left
				mmi.PtMaxTrackSize.Y = mi.RcWork.Bottom - mi.RcWork.Top
			}
		}
		return 0
	case WM_NCCALCSIZE:
		return 0
	case WM_NCACTIVATE:
		return 1
	case WM_NCHITTEST:
		var r RECT
		procGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
		x, y := xFromLParam(lParam), yFromLParam(lParam)
		const edge int32 = 9
		left, right := x < r.Left+edge, x >= r.Right-edge
		top, bottom := y < r.Top+edge, y >= r.Bottom-edge
		switch {
		case top && left:
			return HTTOPLEFT
		case top && right:
			return HTTOPRIGHT
		case bottom && left:
			return HTBOTTOMLEFT
		case bottom && right:
			return HTBOTTOMRIGHT
		case left:
			return HTLEFT
		case right:
			return HTRIGHT
		case top:
			return HTTOP
		case bottom:
			return HTBOTTOM
		default:
			return HTCLIENT
		}
	case WM_SIZE:
		procInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case WM_ERASEBKGND:
		return 1
	case WM_PAINT:
		drawWindow(hwnd)
		return 0
	case WM_TIMER:
		now := time.Now()
		needPaint := false
		if startupActive {
			elapsed := now.Sub(startupStarted)
			if startupHookRequested && !startupHookFinished {
				target := int32(82)
				if elapsed > 900*time.Millisecond {
					target = 94
					startupLabel = "窗口已就绪，快捷键后台初始化中…"
				}
				if startupProgress < target {
					startupProgress += 3
					if startupProgress > target {
						startupProgress = target
					}
				}
			}
			// The application UI is usable independently of the keyboard hook. Do
			// not keep the loading screen open indefinitely if security software
			// takes longer to inspect the hook thread.
			if !startupHookFinished && elapsed > 1500*time.Millisecond && startupFinishAt.IsZero() {
				markStartupComplete("窗口已就绪")
			}
			if !startupFinishAt.IsZero() && now.After(startupFinishAt) {
				startupActive = false
				startupFinishAt = time.Time{}
			}
			needPaint = true
		}

		position := engine.position()
		if engine.playing && engine.end > 0 && position >= engine.end {
			engine.snapshot()
			engine.playing = false
			showFeedback("字幕已结束")
			needPaint = true
		}
		if len(engine.cues) > 0 {
			current := srt.At(engine.cues, position)
			if current != lastSubtitleText {
				needPaint = true
			}
		}
		if progressShouldShow() && engine.playing {
			needPaint = true
		}
		if !progressKeyboardUntil.IsZero() && now.After(progressKeyboardUntil) {
			progressKeyboardUntil = time.Time{}
			needPaint = true
		}
		if feedbackText != "" && now.After(feedbackUntil) {
			feedbackText = ""
			needPaint = true
		}
		if needPaint {
			procInvalidateRect.Call(hwnd, 0, 0)
		}
		return 0
	case WM_MOUSEWHEEL:
		delta := wheelDelta(wParam)
		if delta != 0 {
			steps := int32(delta) / 120
			if steps == 0 {
				if delta > 0 {
					steps = 1
				} else {
					steps = -1
				}
			}
			settings.FontSize += steps * 2
			if settings.FontSize < 12 {
				settings.FontSize = 12
			}
			if settings.FontSize > 96 {
				settings.FontSize = 96
			}
			showFeedback(fmt.Sprintf("字幕字号 %d", settings.FontSize))
		}
		return 0
	case WM_MOUSEMOVE:
		if !trackingMouse {
			t := TRACKMOUSEEVENT{CbSize: uint32(unsafe.Sizeof(TRACKMOUSEEVENT{})), DwFlags: TME_LEAVE, HwndTrack: hwnd}
			procTrackMouseEvent.Call(uintptr(unsafe.Pointer(&t)))
			trackingMouse = true
		}
		if !progressVisible && len(engine.cues) > 0 {
			progressVisible = true
			procInvalidateRect.Call(hwnd, 0, 0)
		}
		if draggingProgress {
			seekFromMouse(xFromLParam(lParam))
			return 0
		}
		if len(engine.cues) > 0 {
			var client RECT
			procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&client)))
			hit := footerButtonHitTest(client, xFromLParam(lParam), yFromLParam(lParam))
			if hit != hoverFooterButton {
				hoverFooterButton = hit
				procInvalidateRect.Call(hwnd, 0, 0)
			}
		}
		return 0
	case WM_MOUSELEAVE:
		trackingMouse = false
		hoverFooterButton = footerButtonNone
		if !draggingProgress && progressVisible {
			progressVisible = false
			procInvalidateRect.Call(hwnd, 0, 0)
		}
		return 0
	case WM_LBUTTONDOWN:
		if len(engine.cues) > 0 {
			var client RECT
			procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&client)))
			x, y := xFromLParam(lParam), yFromLParam(lParam)
			if progressShouldShow() {
				switch footerButtonHitTest(client, x, y) {
				case footerButtonBackward:
					executeRule(1)
					return 0
				case footerButtonPlayPause:
					executeAction(actionPlayPause)
					return 0
				case footerButtonForward:
					executeRule(0)
					return 0
				}
				if progressHitTest(client, x, y) {
					draggingProgress = true
					procSetCapture.Call(hwnd)
					seekFromMouse(x)
					return 0
				}
			}
		}
		procReleaseCapture.Call()
		procSendMessageW.Call(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0)
		return 0
	case WM_LBUTTONUP:
		if draggingProgress {
			draggingProgress = false
			procReleaseCapture.Call()
			var client RECT
			procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&client)))
			if !inRect(xFromLParam(lParam), yFromLParam(lParam), client) {
				progressVisible = false
			}
			procInvalidateRect.Call(hwnd, 0, 0)
			return 0
		}
	case WM_CAPTURECHANGED:
		if draggingProgress {
			draggingProgress = false
			procInvalidateRect.Call(hwnd, 0, 0)
		}
		return 0
	case WM_CONTEXTMENU:
		showContextMenu(hwnd)
		return 0
	case WM_DROPFILES:
		hdrop := wParam
		count, _, _ := procDragQueryFileW.Call(hdrop, ^uintptr(0), 0, 0)
		for i := uintptr(0); i < count; i++ {
			length, _, _ := procDragQueryFileW.Call(hdrop, i, 0, 0)
			if length == 0 {
				continue
			}
			buf := make([]uint16, length+1)
			procDragQueryFileW.Call(hdrop, i, uintptr(unsafe.Pointer(&buf[0])), length+1)
			path := syscall.UTF16ToString(buf)
			if strings.EqualFold(filepath.Ext(path), ".srt") {
				startSubtitleLoad(path)
				break
			}
		}
		procDragFinish.Call(hdrop)
		return 0
	case WM_APP_ACTION:
		executeAction(int(wParam))
		return 0
	case WM_APP_RULE:
		executeRule(int(wParam))
		return 0
	case WM_APP_OPEN_RESULT:
		pendingPathMu.Lock()
		path := pendingPath
		pendingPath = ""
		pendingPathMu.Unlock()
		if path != "" {
			startSubtitleLoad(path)
		}
		return 0
	case WM_APP_SRT_LOADED:
		applySubtitleLoad(uint64(wParam))
		return 0
	case WM_APP_HOOK_STATUS:
		startupHookFinished = true
		if wParam == 0 {
			markStartupComplete("窗口已就绪")
			showFeedback("全局快捷键初始化失败")
		} else {
			markStartupComplete("启动完成")
		}
		return 0
	case WM_APP_START_HOOK:
		if !startupHookRequested {
			startupHookRequested = true
			setStartupStage(55, "正在初始化全局快捷键…")
			startKeyboardHookThread()
		}
		return 0
	case WM_APP_ACTIVATE:
		procShowWindow.Call(hwnd, SW_RESTORE)
		// A layered window does not necessarily receive a useful initial paint
		// region. Render its pixels explicitly whenever an existing instance is
		// activated so it never depends on mouse-wheel or mouse-move invalidation.
		renderLayeredWindow(hwnd)
		procSetForegroundWindow.Call(hwnd)
		return 0
	case WM_COPYDATA:
		cds := (*COPYDATASTRUCT)(unsafe.Pointer(lParam))
		if cds != nil && cds.DwData == 1 && cds.LpData != 0 && cds.CbData >= 2 {
			count := int(cds.CbData / 2)
			buf := unsafe.Slice((*uint16)(unsafe.Pointer(cds.LpData)), count)
			path := syscall.UTF16ToString(buf)
			if path != "" {
				startSubtitleLoad(path)
			}
		}
		return 1
	case WM_CLOSE:
		procDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		procKillTimer.Call(hwnd, 1)
		saveSettings()
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func createChild(class, text string, style uint32, x, y, w, h int32, parent uintptr, id int) uintptr {
	hwnd, _, _ := procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(ptr(class))), uintptr(unsafe.Pointer(ptr(text))), uintptr(style), signed32(x), signed32(y), uintptr(w), uintptr(h), parent, uintptr(id), hInstance, 0)
	font, _, _ := procGetStockObject.Call(17)
	procSendMessageW.Call(hwnd, WM_SETFONT, font, 1)
	if id != 0 {
		controls[id] = hwnd
	}
	return hwnd
}
func moveWindow(hwnd uintptr, x, y, w, h int32) {
	if hwnd != 0 {
		procSetWindowPos.Call(hwnd, 0, signed32(x), signed32(y), uintptr(w), uintptr(h), SWP_NOZORDER|SWP_NOACTIVATE)
	}
}
func moveControl(id int, x, y, w, h int32) { moveWindow(controls[id], x, y, w, h) }
func destroyControl(id int) {
	if hwnd := controls[id]; hwnd != 0 {
		procDestroyWindow.Call(hwnd)
		delete(controls, id)
	}
}
func createShortcutInput(value string, x, y, w int32, parent uintptr, id int) uintptr {
	hwnd := createChild("EDIT", value, WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_AUTOHSCROLL|ES_READONLY, x, y, w, 27, parent, id)
	old, _, _ := procSetWindowLongPtrW.Call(hwnd, ^uintptr(3), shortcutEditCallback)
	editOldProc[hwnd] = old
	return hwnd
}
func createRuleCombo(kind string, parent uintptr, id int) uintptr {
	hwnd := createChild("COMBOBOX", "", WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_VSCROLL|CBS_DROPDOWNLIST, 0, 0, 100, 180, parent, id)
	for _, label := range []string{"快进", "速度 +", "速度 ="} {
		procSendMessageW.Call(hwnd, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(ptr(label))))
	}
	procSendMessageW.Call(hwnd, CB_SETCURSEL, uintptr(ruleKindIndex(kind)), 0)
	return hwnd
}
func getWindowText(hwnd uintptr) string {
	if hwnd == 0 {
		return ""
	}
	buf := make([]uint16, 512)
	n, _, _ := procGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	return syscall.UTF16ToString(buf[:n])
}
func getControlText(id int) string { return getWindowText(controls[id]) }
func setControlText(hwnd uintptr, value string) {
	if hwnd == 0 {
		return
	}
	procSetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(ptr(value))))
	procSendMessageW.Call(hwnd, EM_SETSEL, 0, ^uintptr(0))
}

func shortcutEditProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	old := editOldProc[hwnd]
	switch msg {
	case WM_GETDLGCODE:
		return DLGC_WANTARROWS | DLGC_WANTTAB | DLGC_WANTALLKEYS
	case WM_SETFOCUS:
		procSendMessageW.Call(hwnd, EM_SETSEL, 0, ^uintptr(0))
	case WM_KEYDOWN, WM_SYSKEYDOWN:
		vk := uint32(wParam)
		if isModifier(vk) {
			return 0
		}
		spec := KeySpec{VK: vk, Ctrl: modifierDown(VK_CONTROL), Alt: modifierDown(VK_MENU), Shift: modifierDown(VK_SHIFT), Win: modifierDown(VK_LWIN) || modifierDown(VK_RWIN)}
		setControlText(hwnd, shortcutString(spec))
		return 0
	case WM_CHAR, WM_SYSCHAR:
		return 0
	case WM_NCDESTROY:
		delete(editOldProc, hwnd)
	}
	if old != 0 {
		r, _, _ := procCallWindowProcW.Call(old, hwnd, uintptr(msg), wParam, lParam)
		return r
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func ruleKindIndex(kind string) int {
	switch kind {
	case "speed_add":
		return 1
	case "speed_set":
		return 2
	default:
		return 0
	}
}
func ruleKindFromIndex(index int) string {
	switch index {
	case 1:
		return "speed_add"
	case 2:
		return "speed_set"
	default:
		return "seek"
	}
}
func ruleUnit(kind string) string {
	if kind == "seek" {
		return "s"
	}
	return "倍"
}
func ruleValueText(v float64) string { return strconv.FormatFloat(v, 'f', -1, 64) }
func rulesToDrafts(rules []ShortcutRule) []RuleDraft {
	out := make([]RuleDraft, 0, len(rules))
	for _, r := range rules {
		out = append(out, RuleDraft{Kind: r.Kind, Key: r.Key, ValueText: ruleValueText(r.Value)})
	}
	return out
}
func syncRuleDraftsFromControls() {
	for i := range ruleDrafts {
		if combo := controls[ruleTypeBase+i]; combo != 0 {
			sel, _, _ := procSendMessageW.Call(combo, CB_GETCURSEL, 0, 0)
			ruleDrafts[i].Kind = ruleKindFromIndex(int(sel))
			ruleDrafts[i].Key = getControlText(ruleKeyBase + i)
			ruleDrafts[i].ValueText = getControlText(ruleValueBase + i)
		}
	}
}
func destroyRuleControls() {
	for i := 0; i < maxRules; i++ {
		destroyControl(ruleTypeBase + i)
		destroyControl(ruleKeyBase + i)
		destroyControl(ruleValueBase + i)
		destroyControl(ruleDeleteBase + i)
		destroyControl(ruleUnitBase + i)
	}
}
func rebuildRuleControls() {
	if rulesPanel == 0 {
		return
	}
	destroyRuleControls()
	for i, d := range ruleDrafts {
		combo := createRuleCombo(d.Kind, rulesPanel, ruleTypeBase+i)
		createShortcutInput(d.Key, 0, 0, 200, rulesPanel, ruleKeyBase+i)
		createChild("EDIT", d.ValueText, WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_AUTOHSCROLL, 0, 0, 90, 27, rulesPanel, ruleValueBase+i)
		createChild("STATIC", ruleUnit(d.Kind), WS_CHILD|WS_VISIBLE, 0, 0, 40, 24, rulesPanel, ruleUnitBase+i)
		deleteText := "删除"
		if i < 2 {
			deleteText = "固定"
		}
		deleteButton := createChild("BUTTON", deleteText, WS_CHILD|WS_VISIBLE|WS_TABSTOP, 0, 0, 48, 27, rulesPanel, ruleDeleteBase+i)
		if i < 2 {
			procEnableWindow.Call(combo, 0)
			procEnableWindow.Call(deleteButton, 0)
		}
	}
	layoutRulesPanel()
}
func ruleViewportHeight() int32 {
	if rulesPanel == 0 {
		return 0
	}
	var r RECT
	procGetClientRect.Call(rulesPanel, uintptr(unsafe.Pointer(&r)))
	h := r.Bottom - 60
	if h < 1 {
		h = 1
	}
	return h
}
func maxRuleScroll() int32 {
	content := int32(len(ruleDrafts)) * 36
	max := content - ruleViewportHeight()
	if max < 0 {
		return 0
	}
	return max
}
func updateRuleScrollbar() {
	if rulesPanel == 0 {
		return
	}
	max := maxRuleScroll()
	if settingsScroll < 0 {
		settingsScroll = 0
	}
	if settingsScroll > max {
		settingsScroll = max
	}
	viewport := ruleViewportHeight()
	content := int32(len(ruleDrafts)) * 36
	nmax := content - 1
	if nmax < 0 {
		nmax = 0
	}
	si := SCROLLINFO{CbSize: uint32(unsafe.Sizeof(SCROLLINFO{})), FMask: SIF_RANGE | SIF_PAGE | SIF_POS, NMin: 0, NMax: nmax, NPage: uint32(viewport), NPos: settingsScroll}
	procSetScrollInfo.Call(rulesPanel, SB_VERT, uintptr(unsafe.Pointer(&si)), 1)
}
func layoutRulesPanel() {
	if rulesPanel == 0 {
		return
	}
	var r RECT
	procGetClientRect.Call(rulesPanel, uintptr(unsafe.Pointer(&r)))
	w := r.Right
	margin := int32(10)
	gap := int32(7)
	typeW := int32(102)
	valueW := int32(92)
	unitW := int32(38)
	deleteW := int32(50)
	keyW := w - 2*margin - typeW - valueW - unitW - deleteW - 4*gap
	if keyW < 150 {
		keyW = 150
	}
	xType := margin
	xKey := xType + typeW + gap
	xValue := xKey + keyW + gap
	xUnit := xValue + valueW + gap
	xDelete := xUnit + unitW + gap
	moveControl(ruleHint, margin, 5, w-110, 20)
	moveControl(settingsAddRule, w-78, 4, 66, 26)
	moveControl(ruleHeaderType, xType, 31, typeW, 20)
	moveControl(ruleHeaderKey, xKey, 31, keyW, 20)
	moveControl(ruleHeaderValue, xValue, 31, valueW, 20)
	moveControl(ruleHeaderUnit, xUnit, 31, unitW, 20)
	updateRuleScrollbar()
	for i := range ruleDrafts {
		y := 57 + int32(i)*36 - settingsScroll
		moveControl(ruleTypeBase+i, xType, y, typeW, 180)
		moveControl(ruleKeyBase+i, xKey, y, keyW, 27)
		moveControl(ruleValueBase+i, xValue, y, valueW, 27)
		moveControl(ruleUnitBase+i, xUnit, y+4, unitW, 22)
		moveControl(ruleDeleteBase+i, xDelete, y, deleteW, 27)
	}
}
func scrollRules(delta int32) {
	settingsScroll += delta
	if settingsScroll < 0 {
		settingsScroll = 0
	}
	if max := maxRuleScroll(); settingsScroll > max {
		settingsScroll = max
	}
	layoutRulesPanel()
}

func rulesPanelProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		rulesPanel = hwnd
		createChild("STATIC", "前两条快进用于按钮，不可删除", WS_CHILD|WS_VISIBLE, 0, 0, 300, 20, hwnd, ruleHint)
		createChild("BUTTON", "添加", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 0, 0, 66, 26, hwnd, settingsAddRule)
		createChild("STATIC", "类型", WS_CHILD|WS_VISIBLE, 0, 0, 80, 20, hwnd, ruleHeaderType)
		createChild("STATIC", "快捷键", WS_CHILD|WS_VISIBLE, 0, 0, 120, 20, hwnd, ruleHeaderKey)
		createChild("STATIC", "参数", WS_CHILD|WS_VISIBLE, 0, 0, 70, 20, hwnd, ruleHeaderValue)
		createChild("STATIC", "单位", WS_CHILD|WS_VISIBLE, 0, 0, 40, 20, hwnd, ruleHeaderUnit)
		rebuildRuleControls()
		return 0
	case WM_SIZE:
		layoutRulesPanel()
		return 0
	case WM_VSCROLL:
		code := int(loword(wParam))
		viewport := ruleViewportHeight()
		switch code {
		case SB_LINEUP:
			scrollRules(-36)
		case SB_LINEDOWN:
			scrollRules(36)
		case SB_PAGEUP:
			scrollRules(-viewport)
		case SB_PAGEDOWN:
			scrollRules(viewport)
		case SB_TOP:
			settingsScroll = 0
			layoutRulesPanel()
		case SB_BOTTOM:
			settingsScroll = maxRuleScroll()
			layoutRulesPanel()
		case SB_THUMBPOSITION, SB_THUMBTRACK:
			si := SCROLLINFO{CbSize: uint32(unsafe.Sizeof(SCROLLINFO{})), FMask: SIF_TRACKPOS}
			procGetScrollInfo.Call(hwnd, SB_VERT, uintptr(unsafe.Pointer(&si)))
			settingsScroll = si.NTrackPos
			layoutRulesPanel()
		}
		return 0
	case WM_MOUSEWHEEL:
		d := wheelDelta(wParam)
		if d > 0 {
			scrollRules(-72)
		} else if d < 0 {
			scrollRules(72)
		}
		return 0
	case WM_COMMAND:
		id := int(loword(wParam))
		notify := int(highword(wParam))
		switch {
		case id == settingsAddRule:
			syncRuleDraftsFromControls()
			if len(ruleDrafts) >= maxRules {
				message(settingsWnd, "最多 100 条规则。", "无法添加")
				return 0
			}
			ruleDrafts = append(ruleDrafts, RuleDraft{Kind: "seek", Key: "", ValueText: "5"})
			rebuildRuleControls()
			settingsScroll = maxRuleScroll()
			layoutRulesPanel()
			procSetFocus.Call(controls[ruleKeyBase+len(ruleDrafts)-1])
			return 0
		case id >= ruleDeleteBase && id < ruleDeleteBase+maxRules:
			i := id - ruleDeleteBase
			if i < 2 {
				return 0
			}
			syncRuleDraftsFromControls()
			if i < len(ruleDrafts) {
				ruleDrafts = append(ruleDrafts[:i], ruleDrafts[i+1:]...)
				rebuildRuleControls()
			}
			return 0
		case id >= ruleTypeBase && id < ruleTypeBase+maxRules && notify == CBN_SELCHANGE:
			i := id - ruleTypeBase
			syncRuleDraftsFromControls()
			if i >= 0 && i < len(ruleDrafts) {
				setControlText(controls[ruleUnitBase+i], ruleUnit(ruleDrafts[i].Kind))
			}
			return 0
		}
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func chooseBackgroundColor() {
	cc := CHOOSECOLOR{LStructSize: uint32(unsafe.Sizeof(CHOOSECOLOR{})), HwndOwner: settingsWnd, RgbResult: colorRefFromHex(bgColorDraft), LpCustColors: &customColors[0], Flags: CC_RGBINIT | CC_FULLOPEN}
	r, _, _ := procChooseColorW.Call(uintptr(unsafe.Pointer(&cc)))
	if r != 0 {
		bgColorDraft = hexFromColorRef(cc.RgbResult)
		setControlText(controls[settingsChooseColor], bgColorDraft)
	}
}

func layoutSettings(hwnd uintptr) {
	var r RECT
	procGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
	w, h := r.Right, r.Bottom
	keyW := w - 130
	if keyW < 300 {
		keyW = 300
	}
	moveControl(fieldPlayPause, 110, 48, keyW, 27)
	moveControl(fieldOpen, 110, 80, keyW, 27)
	moveControl(fieldToggle, 110, 112, keyW, 27)
	panelH := h - 210
	if panelH < 220 {
		panelH = 220
	}
	moveWindow(rulesPanel, 16, 150, w-32, panelH)
	by := h - 46
	moveControl(settingsReset, 16, by, 94, 30)
	moveControl(settingsSetDefault, 118, by, 94, 30)
	moveControl(settingsSave, w-204, by, 88, 30)
	moveControl(settingsCancel, w-108, by, 88, 30)
	layoutRulesPanel()
}

func createSettingsControls(hwnd uintptr) {
	controls = map[int]uintptr{}
	createChild("STATIC", "背景", WS_CHILD|WS_VISIBLE, 18, 18, 42, 22, hwnd, 0)
	createChild("BUTTON", bgColorDraft, WS_CHILD|WS_VISIBLE|WS_TABSTOP, 62, 13, 105, 27, hwnd, settingsChooseColor)
	createChild("STATIC", "透明", WS_CHILD|WS_VISIBLE, 188, 18, 42, 22, hwnd, 0)
	createChild("EDIT", strconv.Itoa(settingsDraft.BackgroundTransparency), WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_AUTOHSCROLL, 232, 13, 58, 27, hwnd, fieldBgOpacity)
	createChild("STATIC", "%", WS_CHILD|WS_VISIBLE, 296, 18, 24, 22, hwnd, 0)
	createChild("STATIC", "反馈", WS_CHILD|WS_VISIBLE, 342, 18, 42, 22, hwnd, 0)
	createChild("EDIT", strconv.Itoa(settingsDraft.FeedbackMs), WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_BORDER|ES_AUTOHSCROLL, 386, 13, 70, 27, hwnd, fieldFeedback)
	createChild("STATIC", "ms", WS_CHILD|WS_VISIBLE, 462, 18, 30, 22, hwnd, 0)

	createChild("STATIC", "播放/暂停", WS_CHILD|WS_VISIBLE, 18, 52, 86, 22, hwnd, 0)
	createShortcutInput(settingsDraft.PlayPauseKey, 110, 48, 500, hwnd, fieldPlayPause)
	createChild("STATIC", "打开", WS_CHILD|WS_VISIBLE, 18, 84, 86, 22, hwnd, 0)
	createShortcutInput(settingsDraft.OpenKey, 110, 80, 500, hwnd, fieldOpen)
	createChild("STATIC", "总开关", WS_CHILD|WS_VISIBLE, 18, 116, 86, 22, hwnd, 0)
	createShortcutInput(settingsDraft.ToggleKeysKey, 110, 112, 500, hwnd, fieldToggle)

	rulesPanel = createChild("SRTPlayerRulesPanelClass", "", WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_BORDER, 16, 150, 700, 350, hwnd, 0)
	createChild("BUTTON", "重置设置", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 16, 540, 94, 30, hwnd, settingsReset)
	createChild("BUTTON", "设为默认", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 118, 540, 94, 30, hwnd, settingsSetDefault)
	createChild("BUTTON", "保存", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 530, 540, 88, 30, hwnd, settingsSave)
	createChild("BUTTON", "取消", WS_CHILD|WS_VISIBLE|WS_TABSTOP, 626, 540, 88, 30, hwnd, settingsCancel)
	layoutSettings(hwnd)
}

func readSettingsFromWindow() (Settings, bool) {
	syncRuleDraftsFromControls()
	candidate := settings
	snapshotWindowGeometry(&candidate)
	seen := map[string]string{}
	addKey := func(label, value string) (string, bool) {
		canonical, err := canonicalShortcut(value)
		if err != nil {
			message(settingsWnd, label+"快捷键无效。", "设置错误")
			return "", false
		}
		upper := strings.ToUpper(canonical)
		if other, ok := seen[upper]; ok {
			message(settingsWnd, label+"与"+other+"重复。", "快捷键冲突")
			return "", false
		}
		seen[upper] = label
		return canonical, true
	}
	var ok bool
	if candidate.PlayPauseKey, ok = addKey("播放/暂停", getControlText(fieldPlayPause)); !ok {
		return Settings{}, false
	}
	if candidate.OpenKey, ok = addKey("打开", getControlText(fieldOpen)); !ok {
		return Settings{}, false
	}
	if candidate.ToggleKeysKey, ok = addKey("总开关", getControlText(fieldToggle)); !ok {
		return Settings{}, false
	}

	if len(ruleDrafts) < 2 {
		message(settingsWnd, "前两条快进规则必须保留。", "设置错误")
		return Settings{}, false
	}
	rules := make([]ShortcutRule, 0, len(ruleDrafts))
	for i, d := range ruleDrafts {
		key, good := addKey(fmt.Sprintf("规则 %d", i+1), d.Key)
		if !good {
			return Settings{}, false
		}
		value, err := strconv.ParseFloat(strings.TrimSpace(d.ValueText), 64)
		if err != nil {
			message(settingsWnd, fmt.Sprintf("规则 %d 参数无效。", i+1), "设置错误")
			return Settings{}, false
		}
		if i == 0 && (d.Kind != "seek" || value <= 0) {
			message(settingsWnd, "第 1 条必须是正数快进。", "设置错误")
			return Settings{}, false
		}
		if i == 1 && (d.Kind != "seek" || value >= 0) {
			message(settingsWnd, "第 2 条必须是负数后退。", "设置错误")
			return Settings{}, false
		}
		r := ShortcutRule{Kind: d.Kind, Key: key, Value: value}
		switch d.Kind {
		case "seek":
			if value == 0 || value < -3600 || value > 3600 {
				message(settingsWnd, "快进参数需在 -3600 到 3600 s，且不能为 0。", "设置错误")
				return Settings{}, false
			}
		case "speed_add":
			if value == 0 || value < -5 || value > 5 {
				message(settingsWnd, "速度 + 参数需在 -5 到 5 倍，且不能为 0。", "设置错误")
				return Settings{}, false
			}
		case "speed_set":
			if value < 0.1 || value > 10 {
				message(settingsWnd, "速度 = 参数需在 0.1 到 10 倍。", "设置错误")
				return Settings{}, false
			}
		default:
			message(settingsWnd, "规则类型无效。", "设置错误")
			return Settings{}, false
		}
		rules = append(rules, r)
	}
	candidate.Rules = rules
	fb, err := strconv.Atoi(strings.TrimSpace(getControlText(fieldFeedback)))
	if err != nil || fb < 100 || fb > 5000 {
		message(settingsWnd, "反馈时间需在 100 到 5000 ms。", "设置错误")
		return Settings{}, false
	}
	opacity, err := strconv.Atoi(strings.TrimSpace(getControlText(fieldBgOpacity)))
	if err != nil || opacity < 0 || opacity > 100 {
		message(settingsWnd, "背景透明度需在 0 到 100%。", "设置错误")
		return Settings{}, false
	}
	candidate.FeedbackMs = fb
	candidate.BackgroundTransparency = opacity
	candidate.BackgroundColor = bgColorDraft
	return normalizeSettings(candidate), true
}

func applySettings(candidate Settings, moveMain bool) {
	settings = normalizeSettings(candidate)
	refreshShortcutConfig()
	if moveMain && mainWnd != 0 {
		procSetWindowPos.Call(mainWnd, 0, signed32(settings.WindowX), signed32(settings.WindowY), uintptr(settings.WindowWidth), uintptr(settings.WindowHeight), SWP_NOZORDER|SWP_NOACTIVATE)
	}
	saveSettings()
	procInvalidateRect.Call(mainWnd, 0, 0)
}
func populateSettingsWindow(candidate Settings) {
	settingsDraft = candidate
	bgColorDraft = candidate.BackgroundColor
	ruleDrafts = rulesToDrafts(candidate.Rules)
	settingsScroll = 0
	setControlText(controls[settingsChooseColor], bgColorDraft)
	setControlText(controls[fieldBgOpacity], strconv.Itoa(candidate.BackgroundTransparency))
	setControlText(controls[fieldFeedback], strconv.Itoa(candidate.FeedbackMs))
	setControlText(controls[fieldPlayPause], candidate.PlayPauseKey)
	setControlText(controls[fieldOpen], candidate.OpenKey)
	setControlText(controls[fieldToggle], candidate.ToggleKeysKey)
	rebuildRuleControls()
}

func settingsWndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		settingsWnd = hwnd
		settingsOpen.Store(true)
		createSettingsControls(hwnd)
		return 0
	case WM_GETMINMAXINFO:
		mmi := (*MINMAXINFO)(unsafe.Pointer(lParam))
		mmi.PtMinTrackSize.X = 720
		mmi.PtMinTrackSize.Y = 520
		return 0
	case WM_SIZE:
		layoutSettings(hwnd)
		return 0
	case WM_COMMAND:
		switch int(loword(wParam)) {
		case settingsChooseColor:
			chooseBackgroundColor()
		case settingsSave:
			if candidate, ok := readSettingsFromWindow(); ok {
				applySettings(candidate, false)
				showFeedback("设置已保存")
				procDestroyWindow.Call(hwnd)
			}
		case settingsCancel:
			procDestroyWindow.Call(hwnd)
		case settingsSetDefault:
			if candidate, ok := readSettingsFromWindow(); ok {
				applySettings(candidate, false)
				writeUserDefaults(settings)
				settingsDraft = settings
				message(hwnd, "当前设置已设为默认。", "设为默认")
			}
		case settingsReset:
			candidate := loadUserDefaults()
			var wr RECT
			procGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&wr)))
			candidate.SettingsWidth = wr.Right - wr.Left
			candidate.SettingsHeight = wr.Bottom - wr.Top
			applySettings(candidate, true)
			populateSettingsWindow(settings)
			showFeedback("设置已重置")
		}
		return 0
	case WM_CLOSE:
		procDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		var r RECT
		procGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
		settings.SettingsWidth = r.Right - r.Left
		settings.SettingsHeight = r.Bottom - r.Top
		writeSettings(settings)
		settingsWnd = 0
		settingsOpen.Store(false)
		rulesPanel = 0
		controls = map[int]uintptr{}
		ruleDrafts = nil
		return 0
	}
	r, _, _ := procDefWindowProcW.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func ensureSettingsClasses() error {
	if settingsClassesRegistered {
		return nil
	}
	settingsProcCallback = syscall.NewCallback(settingsWndProc)
	rulesPanelCallback = syscall.NewCallback(rulesPanelProc)
	shortcutEditCallback = syscall.NewCallback(shortcutEditProc)
	if err := registerWindowClass("SRTPlayerSettingsClass", settingsProcCallback, uintptr(COLOR_WINDOW+1), CS_HREDRAW|CS_VREDRAW); err != nil {
		return err
	}
	if err := registerWindowClass("SRTPlayerRulesPanelClass", rulesPanelCallback, uintptr(COLOR_WINDOW+1), CS_HREDRAW|CS_VREDRAW); err != nil {
		return err
	}
	settingsClassesRegistered = true
	return nil
}

func openSettingsWindow() {
	if settingsWnd != 0 {
		procSetForegroundWindow.Call(settingsWnd)
		return
	}
	if err := ensureSettingsClasses(); err != nil {
		message(mainWnd, "无法初始化设置界面。", "设置错误")
		return
	}
	settingsDraft = settings
	bgColorDraft = settings.BackgroundColor
	ruleDrafts = rulesToDrafts(settings.Rules)
	settingsScroll = 0
	settingsWnd, _, _ = procCreateWindowExW.Call(0, uintptr(unsafe.Pointer(ptr("SRTPlayerSettingsClass"))), uintptr(unsafe.Pointer(ptr("SRT Player 设置"))), WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_THICKFRAME, 440, 70, uintptr(settings.SettingsWidth), uintptr(settings.SettingsHeight), mainWnd, 0, hInstance, 0)
	procShowWindow.Call(settingsWnd, SW_SHOW)
	procUpdateWindow.Call(settingsWnd)
}

func registerWindowClass(name string, wndProc uintptr, background uintptr, style uint32) error {
	cursor, _, _ := procLoadCursorW.Call(0, IDC_ARROW)
	icon, _, _ := procLoadIconW.Call(hInstance, 1)
	c := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), Style: style, LpfnWndProc: wndProc, HInstance: hInstance, HIcon: icon, HCursor: cursor, HbrBackground: background, LpszClassName: ptr(name), HIconSm: icon}
	r, _, err := procRegisterClassExW.Call(uintptr(unsafe.Pointer(&c)))
	if r == 0 {
		return err
	}
	return nil
}

func main() {
	runtime.LockOSThread()
	startupStarted = time.Now()
	startupActive = true
	startupProgress = 18
	startupLabel = "正在读取设置…"
	startupHookRequested = false
	startupHookFinished = false
	startupFinishAt = time.Time{}
	procSetProcessDPIAware.Call()
	hInstance, _, _ = procGetModuleHandleW.Call(0)

	initialPath := ""
	if len(os.Args) > 1 {
		initialPath = os.Args[1]
	}
	if !createSingleInstance() {
		forwardToExisting(initialPath)
		return
	}

	settings = loadSettings()
	sanitizeWindowPlacement(&settings)
	shortcutsEnabled.Store(true)
	refreshShortcutConfig()

	mainProc := syscall.NewCallback(mainWndProc)
	hookCallback = syscall.NewCallback(keyboardProc)

	// Register only the subtitle window during startup. The settings UI remains
	// lazy and is created only when requested.
	if err := registerWindowClass("SRTPlayerMainClass", mainProc, 0, 0); err != nil {
		panic(err)
	}

	mainWnd, _, _ = procCreateWindowExW.Call(WS_EX_TOPMOST|WS_EX_TOOLWINDOW|WS_EX_LAYERED, uintptr(unsafe.Pointer(ptr("SRTPlayerMainClass"))), uintptr(unsafe.Pointer(ptr(appName))), WS_POPUP|WS_THICKFRAME, signed32(settings.WindowX), signed32(settings.WindowY), uintptr(settings.WindowWidth), uintptr(settings.WindowHeight), 0, 0, hInstance, 0)
	if mainWnd == 0 {
		panic("CreateWindowExW failed")
	}
	borderNone := uint32(0xFFFFFFFE)
	procDwmSetWindowAttribute.Call(mainWnd, 34, uintptr(unsafe.Pointer(&borderNone)), 4)
	procShowWindow.Call(mainWnd, SW_SHOW)
	// WS_EX_LAYERED windows can be logically shown while still having no pixel
	// surface. Render the startup frame explicitly before any hook initialization;
	// this fixes the old behaviour where a mouse-wheel event was needed to make
	// the window appear.
	startupProgress = 32
	startupLabel = "正在显示窗口…"
	renderLayeredWindow(mainWnd)
	procUpdateWindow.Call(mainWnd)

	// Start the global keyboard hook only after the subtitle window has already
	// been rendered and the UI message loop is about to run. The hook itself owns
	// a separate locked Windows thread and cannot block the subtitle UI.
	procPostMessageW.Call(mainWnd, WM_APP_START_HOOK, 0, 0)
	if initialPath != "" {
		pendingPathMu.Lock()
		pendingPath = initialPath
		pendingPathMu.Unlock()
		procPostMessageW.Call(mainWnd, WM_APP_OPEN_RESULT, 0, 0)
	}

	var msg MSG
	for {
		r, _, _ := procGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		procDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}

	stopKeyboardHookThread()
	if instanceMutex != 0 {
		procCloseHandle.Call(instanceMutex)
		instanceMutex = 0
	}
}
