$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command go -ErrorAction SilentlyContinue)) {
    throw "Go was not found. Install Go 1.21 or newer first."
}

New-Item -ItemType Directory -Force -Path dist | Out-Null
New-Item -ItemType Directory -Force -Path cmd\installer\payload | Out-Null

Write-Host "Testing SRT parser..."
go test .\internal\srt

$env:GOOS = "windows"
$env:GOARCH = "amd64"
$env:CGO_ENABLED = "0"

Write-Host "Building SRT Player..."
go build -trimpath -ldflags "-s -w -H=windowsgui" -o dist\SRTPlayer.exe .\cmd\player

Write-Host "Building uninstaller..."
go build -trimpath -ldflags "-s -w -H=windowsgui" -o dist\uninstall.exe .\cmd\uninstaller

Write-Host "Embedding application icon..."
go run .\tools\embedicon -exe dist\SRTPlayer.exe -ico assets\SRTPlayer.ico
go run .\tools\embedicon -exe dist\uninstall.exe -ico assets\SRTPlayer.ico

Copy-Item -Force dist\SRTPlayer.exe cmd\installer\payload\SRTPlayer.exe
Copy-Item -Force dist\uninstall.exe cmd\installer\payload\uninstall.exe
Copy-Item -Force README.md cmd\installer\payload\README.md
Copy-Item -Force LICENSE.txt cmd\installer\payload\LICENSE.txt
Copy-Item -Force settings.json cmd\installer\payload\settings.json
Copy-Item -Force default_settings.json cmd\installer\payload\default_settings.json
Copy-Item -Force factory_settings.json cmd\installer\payload\factory_settings.json
$sourceNotice = @"
Source code is supplied in the separate source archive.
License: MIT. Copyright (c) 2026 GenesisX1242.
Upstream interaction reference: https://github.com/carsonip/Penguin-Subtitle-Player
This is an independent Windows-oriented reimplementation, not an official upstream binary.
Version 1.0.0 contains the complete current feature set, explicitly renders the layered window before the message loop, shows a startup progress bar, and initializes the global keyboard hook only after the first visible frame. It also includes the dedicated hook thread, single-instance forwarding, visible-window correction, asynchronous SRT parsing, and native Windows file dialog.
All runtime configuration files are stored beside SRTPlayer.exe in the selected installation directory.
"@
[System.IO.File]::WriteAllText((Join-Path $PSScriptRoot "cmd\installer\payload\SOURCE.txt"), $sourceNotice, (New-Object System.Text.UTF8Encoding($false)))

Write-Host "Building installer..."
go build -trimpath -ldflags "-s -w -H=windowsgui" -o dist\SRTPlayer-Setup-1.0.0.exe .\cmd\installer
go run .\tools\embedicon -exe dist\SRTPlayer-Setup-1.0.0.exe -ico assets\SRTPlayer.ico

Copy-Item -Force dist\SRTPlayer.exe dist\SRTPlayer-1.0.0.exe

Get-FileHash dist\*.exe -Algorithm SHA256 | Format-Table -AutoSize
Write-Host "Build complete: $PSScriptRoot\dist"
