package main

import (
	"encoding/binary"
	"errors"
	"flag"
	"fmt"
	"os"
)

type icoEntry struct {
	width, height, colors, reserved byte
	planes, bitCount                uint16
	data                            []byte
}

func align(v, a uint32) uint32 {
	if a == 0 {
		return v
	}
	return (v + a - 1) &^ (a - 1)
}

func parseICO(data []byte) ([]icoEntry, error) {
	if len(data) < 6 || binary.LittleEndian.Uint16(data[0:2]) != 0 || binary.LittleEndian.Uint16(data[2:4]) != 1 {
		return nil, errors.New("invalid ICO header")
	}
	count := int(binary.LittleEndian.Uint16(data[4:6]))
	if count < 1 || len(data) < 6+16*count {
		return nil, errors.New("invalid ICO directory")
	}
	out := make([]icoEntry, 0, count)
	for i := 0; i < count; i++ {
		off := 6 + i*16
		size := binary.LittleEndian.Uint32(data[off+8 : off+12])
		pos := binary.LittleEndian.Uint32(data[off+12 : off+16])
		if uint64(pos)+uint64(size) > uint64(len(data)) {
			return nil, errors.New("ICO image outside file")
		}
		out = append(out, icoEntry{
			width: data[off], height: data[off+1], colors: data[off+2], reserved: data[off+3],
			planes: binary.LittleEndian.Uint16(data[off+4 : off+6]), bitCount: binary.LittleEndian.Uint16(data[off+6 : off+8]),
			data: append([]byte(nil), data[pos:pos+size]...),
		})
	}
	return out, nil
}

func putDir(buf []byte, off uint32, ids uint16) {
	binary.LittleEndian.PutUint16(buf[off+12:off+14], 0)
	binary.LittleEndian.PutUint16(buf[off+14:off+16], ids)
}
func putEntry(buf []byte, off, name, target uint32, directory bool) {
	binary.LittleEndian.PutUint32(buf[off:off+4], name)
	if directory {
		target |= 0x80000000
	}
	binary.LittleEndian.PutUint32(buf[off+4:off+8], target)
}

func buildResource(images []icoEntry, baseRVA uint32) []byte {
	n := len(images)
	rootOff := uint32(0)
	iconTypeOff := rootOff + 16 + 2*8
	groupTypeOff := iconTypeOff + 16 + uint32(n)*8
	langBase := groupTypeOff + 16 + 8
	groupLangOff := langBase + uint32(n)*24
	dataEntryBase := groupLangOff + 24
	contentBase := align(dataEntryBase+uint32(n+1)*16, 4)

	offsets := make([]uint32, n+1)
	cursor := contentBase
	for i, img := range images {
		offsets[i] = cursor
		cursor = align(cursor+uint32(len(img.data)), 4)
	}

	groupSize := 6 + n*14
	offsets[n] = cursor
	cursor = align(cursor+uint32(groupSize), 4)
	buf := make([]byte, cursor)

	putDir(buf, rootOff, 2)
	putEntry(buf, rootOff+16, 3, iconTypeOff, true)
	putEntry(buf, rootOff+24, 14, groupTypeOff, true)

	putDir(buf, iconTypeOff, uint16(n))
	for i := 0; i < n; i++ {
		langOff := langBase + uint32(i)*24
		putEntry(buf, iconTypeOff+16+uint32(i)*8, uint32(i+1), langOff, true)
		putDir(buf, langOff, 1)
		putEntry(buf, langOff+16, 1033, dataEntryBase+uint32(i)*16, false)
		de := dataEntryBase + uint32(i)*16
		binary.LittleEndian.PutUint32(buf[de:de+4], baseRVA+offsets[i])
		binary.LittleEndian.PutUint32(buf[de+4:de+8], uint32(len(images[i].data)))
		copy(buf[offsets[i]:], images[i].data)
	}

	putDir(buf, groupTypeOff, 1)
	putEntry(buf, groupTypeOff+16, 1, groupLangOff, true)
	putDir(buf, groupLangOff, 1)
	putEntry(buf, groupLangOff+16, 1033, dataEntryBase+uint32(n)*16, false)
	gde := dataEntryBase + uint32(n)*16
	binary.LittleEndian.PutUint32(buf[gde:gde+4], baseRVA+offsets[n])
	binary.LittleEndian.PutUint32(buf[gde+4:gde+8], uint32(groupSize))

	g := buf[offsets[n]:]
	binary.LittleEndian.PutUint16(g[0:2], 0)
	binary.LittleEndian.PutUint16(g[2:4], 1)
	binary.LittleEndian.PutUint16(g[4:6], uint16(n))
	for i, img := range images {
		e := g[6+i*14 : 6+(i+1)*14]
		e[0], e[1], e[2], e[3] = img.width, img.height, img.colors, img.reserved
		binary.LittleEndian.PutUint16(e[4:6], img.planes)
		binary.LittleEndian.PutUint16(e[6:8], img.bitCount)
		binary.LittleEndian.PutUint32(e[8:12], uint32(len(img.data)))
		binary.LittleEndian.PutUint16(e[12:14], uint16(i+1))
	}
	return buf
}

func patchPE(exePath, icoPath string) error {
	exe, err := os.ReadFile(exePath)
	if err != nil {
		return err
	}
	ico, err := os.ReadFile(icoPath)
	if err != nil {
		return err
	}
	images, err := parseICO(ico)
	if err != nil {
		return err
	}
	if len(exe) < 0x100 || string(exe[0:2]) != "MZ" {
		return errors.New("not a PE executable")
	}
	peOff := binary.LittleEndian.Uint32(exe[0x3c:0x40])
	if int(peOff)+24 > len(exe) || string(exe[peOff:peOff+4]) != "PE\x00\x00" {
		return errors.New("invalid PE header")
	}
	fileHdr := peOff + 4
	sections := binary.LittleEndian.Uint16(exe[fileHdr+2 : fileHdr+4])
	optSize := binary.LittleEndian.Uint16(exe[fileHdr+16 : fileHdr+18])
	opt := fileHdr + 20
	if int(opt)+int(optSize) > len(exe) {
		return errors.New("truncated optional header")
	}
	magic := binary.LittleEndian.Uint16(exe[opt : opt+2])
	var ddOff uint32
	switch magic {
	case 0x10b:
		ddOff = 96
	case 0x20b:
		ddOff = 112
	default:
		return errors.New("unsupported PE format")
	}
	sectionAlign := binary.LittleEndian.Uint32(exe[opt+32 : opt+36])
	fileAlign := binary.LittleEndian.Uint32(exe[opt+36 : opt+40])
	sizeHeaders := binary.LittleEndian.Uint32(exe[opt+60 : opt+64])
	sectionTable := opt + uint32(optSize)
	newHeader := sectionTable + uint32(sections)*40
	if newHeader+40 > sizeHeaders {
		return errors.New("no room for another PE section header")
	}
	resourceDD := opt + ddOff + 2*8
	if binary.LittleEndian.Uint32(exe[resourceDD:resourceDD+4]) != 0 {
		return errors.New("executable already has resources")
	}

	var maxVAEnd, maxRawEnd uint32
	for i := uint16(0); i < sections; i++ {
		sh := sectionTable + uint32(i)*40
		vs := binary.LittleEndian.Uint32(exe[sh+8 : sh+12])
		va := binary.LittleEndian.Uint32(exe[sh+12 : sh+16])
		rs := binary.LittleEndian.Uint32(exe[sh+16 : sh+20])
		rp := binary.LittleEndian.Uint32(exe[sh+20 : sh+24])
		if e := va + align(vs, sectionAlign); e > maxVAEnd {
			maxVAEnd = e
		}
		if e := rp + rs; e > maxRawEnd {
			maxRawEnd = e
		}
	}
	newVA := align(maxVAEnd, sectionAlign)
	res := buildResource(images, newVA)
	rawPtr := align(uint32(len(exe)), fileAlign)
	if rawPtr < align(maxRawEnd, fileAlign) {
		rawPtr = align(maxRawEnd, fileAlign)
	}
	rawSize := align(uint32(len(res)), fileAlign)
	out := make([]byte, int(rawPtr+rawSize))
	copy(out, exe)
	copy(out[rawPtr:], res)

	sh := newHeader
	copy(out[sh:sh+8], []byte(".rsrc\x00\x00\x00"))
	binary.LittleEndian.PutUint32(out[sh+8:sh+12], uint32(len(res)))
	binary.LittleEndian.PutUint32(out[sh+12:sh+16], newVA)
	binary.LittleEndian.PutUint32(out[sh+16:sh+20], rawSize)
	binary.LittleEndian.PutUint32(out[sh+20:sh+24], rawPtr)
	binary.LittleEndian.PutUint32(out[sh+36:sh+40], 0x40000040)

	binary.LittleEndian.PutUint16(out[fileHdr+2:fileHdr+4], sections+1)
	binary.LittleEndian.PutUint32(out[opt+56:opt+60], align(newVA+uint32(len(res)), sectionAlign))
	initData := binary.LittleEndian.Uint32(out[opt+8 : opt+12])
	binary.LittleEndian.PutUint32(out[opt+8:opt+12], initData+rawSize)
	binary.LittleEndian.PutUint32(out[resourceDD:resourceDD+4], newVA)
	binary.LittleEndian.PutUint32(out[resourceDD+4:resourceDD+8], uint32(len(res)))
	binary.LittleEndian.PutUint32(out[opt+64:opt+68], 0)

	return os.WriteFile(exePath, out, 0o755)
}

func main() {
	exe := flag.String("exe", "", "Windows executable to patch")
	ico := flag.String("ico", "", "ICO file")
	flag.Parse()
	if *exe == "" || *ico == "" {
		fmt.Fprintln(os.Stderr, "usage: embedicon -exe app.exe -ico app.ico")
		os.Exit(2)
	}
	if err := patchPE(*exe, *ico); err != nil {
		fmt.Fprintln(os.Stderr, "embedicon:", err)
		os.Exit(1)
	}
}
