# Third-party notice

SRT Player is an independent Windows-oriented implementation inspired by the interaction model of Penguin Subtitle Player:

https://github.com/carsonip/Penguin-Subtitle-Player

Penguin Subtitle Player is licensed under GPL-3.0. No upstream Qt/GPL source files are included in this Go/Win32 source tree. This project is not an official upstream release.
