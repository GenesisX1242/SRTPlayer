package srt

import (
	"bufio"
	"html"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type Cue struct {
	Start time.Duration
	End   time.Duration
	Text  string
}

var (
	timingRE = regexp.MustCompile(`(?i)^\s*(\d{1,3}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,3}):(\d{2}):(\d{2})[,.](\d{1,3})`)
	tagRE    = regexp.MustCompile(`<[^>]+>`)
)

func ParseFile(path string) ([]Cue, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	return Parse(data), nil
}

func Parse(data []byte) []Cue {
	text := strings.TrimPrefix(string(data), "\ufeff")
	text = strings.ReplaceAll(text, "\r\n", "\n")
	text = strings.ReplaceAll(text, "\r", "\n")

	scanner := bufio.NewScanner(strings.NewReader(text))
	scanner.Buffer(make([]byte, 4096), 4*1024*1024)
	var lines []string
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}

	var cues []Cue
	for i := 0; i < len(lines); {
		line := strings.TrimSpace(lines[i])
		match := timingRE.FindStringSubmatch(line)
		if match == nil {
			i++
			continue
		}
		start := parseTimestamp(match[1:5])
		end := parseTimestamp(match[5:9])
		i++

		var body []string
		for i < len(lines) && strings.TrimSpace(lines[i]) != "" {
			body = append(body, lines[i])
			i++
		}
		clean := cleanText(strings.Join(body, "\n"))
		if end > start && clean != "" {
			cues = append(cues, Cue{Start: start, End: end, Text: clean})
		}
		for i < len(lines) && strings.TrimSpace(lines[i]) == "" {
			i++
		}
	}

	sort.SliceStable(cues, func(i, j int) bool { return cues[i].Start < cues[j].Start })
	return cues
}

func parseTimestamp(parts []string) time.Duration {
	values := make([]int64, 4)
	for i, part := range parts {
		values[i], _ = strconv.ParseInt(part, 10, 64)
	}
	ms := values[3]
	if len(parts[3]) == 1 {
		ms *= 100
	} else if len(parts[3]) == 2 {
		ms *= 10
	}
	total := ((values[0]*60+values[1])*60+values[2])*1000 + ms
	return time.Duration(total) * time.Millisecond
}

func cleanText(value string) string {
	value = strings.ReplaceAll(value, "{\\an8}", "")
	value = strings.ReplaceAll(value, "{\\an7}", "")
	value = tagRE.ReplaceAllString(value, "")
	value = html.UnescapeString(value)
	value = strings.TrimSpace(value)
	return value
}

func At(cues []Cue, position time.Duration) string {
	if len(cues) == 0 {
		return ""
	}
	i := sort.Search(len(cues), func(i int) bool { return cues[i].Start > position }) - 1
	if i >= 0 && position >= cues[i].Start && position <= cues[i].End {
		return cues[i].Text
	}
	return ""
}

func End(cues []Cue) time.Duration {
	if len(cues) == 0 {
		return 0
	}
	end := cues[0].End
	for _, cue := range cues[1:] {
		if cue.End > end {
			end = cue.End
		}
	}
	return end
}
