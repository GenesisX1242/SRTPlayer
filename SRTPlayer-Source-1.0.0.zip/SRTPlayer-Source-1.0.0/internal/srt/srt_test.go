package srt

import (
	"testing"
	"time"
)

func TestParseAndLookup(t *testing.T) {
	input := []byte("1\r\n00:00:01,000 --> 00:00:03,500\r\n<b>Hello</b>\r\nWorld\r\n\r\n2\r\n00:00:04.000 --> 00:00:05.000\r\nSecond\r\n")
	cues := Parse(input)
	if len(cues) != 2 {
		t.Fatalf("expected 2 cues, got %d", len(cues))
	}
	if got := At(cues, 2*time.Second); got != "Hello\nWorld" {
		t.Fatalf("unexpected cue: %q", got)
	}
	if got := At(cues, 3800*time.Millisecond); got != "" {
		t.Fatalf("expected gap, got %q", got)
	}
}
